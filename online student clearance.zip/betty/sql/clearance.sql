-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 04, 2025 at 08:04 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clearance`
--

-- --------------------------------------------------------

--
-- Table structure for table `assiment`
--

DROP TABLE IF EXISTS `assiment`;
CREATE TABLE IF NOT EXISTS `assiment` (
  `assiment_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `faculty_id` int DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  `staff_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `due_date` date DEFAULT NULL,
  `status` enum('Pending','Submitted','Reviewed','Completed') DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`assiment_id`),
  KEY `fk_assiment_student` (`student_id`),
  KEY `fk_assiment_faculty` (`faculty_id`),
  KEY `fk_assiment_dept` (`dept_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `assiment`
--

INSERT INTO `assiment` (`assiment_id`, `student_id`, `faculty_id`, `dept_id`, `staff_id`, `title`, `description`, `due_date`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 3, 6, 'Clearance Assignment', '\r\nReason: Please provide a reason for your clearance request. This will be sent to the staff member', '2025-10-01', '', '2025-10-01 14:38:38', '2025-10-01 14:39:08'),
(2, 1, 1, 3, 5, 'Clearance Assignment', 'fdgmjh', NULL, 'Pending', '2025-10-02 09:13:51', '2025-10-02 09:13:51');

-- --------------------------------------------------------

--
-- Table structure for table `clearance`
--

DROP TABLE IF EXISTS `clearance`;
CREATE TABLE IF NOT EXISTS `clearance` (
  `clearance_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `faculty_id` int DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  `staff_id` int DEFAULT NULL,
  `status` enum('Pending','Cleared','Rejected') DEFAULT 'Pending',
  `remarks` text,
  `reason` varchar(500) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `appointment_date` date DEFAULT NULL,
  PRIMARY KEY (`clearance_id`),
  KEY `fk_clearance_faculty` (`faculty_id`),
  KEY `fk_clearance_dept` (`dept_id`),
  KEY `student_id` (`student_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `clearance`
--

INSERT INTO `clearance` (`clearance_id`, `student_id`, `faculty_id`, `dept_id`, `staff_id`, `status`, `remarks`, `reason`, `updated_at`, `appointment_date`) VALUES
(1, 1, 1, 3, 4, 'Pending', 'Waiting for review', 'Please provide a reason for your clearance request. This will be sent to the staff member', '2025-10-01 13:08:36', NULL),
(2, 1, 1, 3, 5, 'Pending', 'Waiting for review', 'Please provide a reason for your clearance request. This will be sent to the staff member', '2025-10-01 08:56:52', NULL),
(3, 1, 1, 3, 6, 'Cleared', 'This will be sent to the staff member', 'Please provide a reason for your clearance request. This will be sent to the staff member', '2025-10-01 14:39:08', '2025-10-10'),
(4, 1, 1, 3, 2, 'Pending', 'Waiting for review', 'chjvkjhnkll', '2025-10-01 09:19:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `dept_id` int NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(100) NOT NULL,
  `faculty_id` int DEFAULT NULL,
  PRIMARY KEY (`dept_id`),
  KEY `faculty_id` (`faculty_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `dept_name`, `faculty_id`) VALUES
(1, 'Information Systems and Management', 1),
(2, 'IT Networking', 1),
(3, 'Software Development', 1),
(4, 'Law', 2),
(5, 'Finance', 3),
(6, 'Accounting', 3),
(7, 'Marketing', 3),
(8, 'Human Resources Management', 3),
(9, 'Cooperatives Management', 3),
(10, 'Economics', 3),
(11, 'Rural Development', 4),
(12, 'Emergency and Disaster Management', 4),
(13, 'Economic and Entrepreneurship', 5),
(14, 'Mathematics and Economic Mathematics', 5),
(15, 'Geography', 5),
(16, 'Computer Sciences', 5);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_id` int NOT NULL AUTO_INCREMENT,
  `faculty_name` varchar(100) NOT NULL,
  PRIMARY KEY (`faculty_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `faculty_name`) VALUES
(1, 'Computing and Information Sciences'),
(2, 'Law'),
(3, 'Economic Sciences and Management'),
(4, 'Environment Sciences'),
(5, 'Education');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
CREATE TABLE IF NOT EXISTS `module` (
  `module_id` int NOT NULL AUTO_INCREMENT,
  `module_name` varchar(100) NOT NULL,
  `dept_id` int DEFAULT NULL,
  `faculty_id` int DEFAULT NULL,
  `staff_id` int DEFAULT NULL,
  PRIMARY KEY (`module_id`),
  KEY `dept_id` (`dept_id`),
  KEY `faculty_id` (`faculty_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`module_id`, `module_name`, `dept_id`, `faculty_id`, `staff_id`) VALUES
(1, 'Introduction to Programming', 3, 1, NULL),
(2, 'Database Systems', 3, 1, NULL),
(3, 'Web Technologies', 3, 1, NULL),
(4, 'Software Engineering', 3, 1, NULL),
(5, 'Data Structures and Algorithms', 3, 1, NULL),
(6, 'Computer Networks', 2, 1, NULL),
(7, 'Network Security', 2, 1, NULL),
(8, 'Systems Administration', 2, 1, NULL),
(9, 'Information Systems Management', 1, 1, NULL),
(10, 'IT Project Management', 1, 1, NULL),
(11, 'Introduction to Law', 4, 2, NULL),
(12, 'Constitutional Law', 4, 2, NULL),
(13, 'Criminal Law', 4, 2, NULL),
(14, 'Civil Procedure', 4, 2, NULL),
(15, 'International Law', 4, 2, NULL),
(16, 'Human Rights Law', 4, 2, NULL),
(17, 'Contract Law', 4, 2, NULL),
(18, 'Commercial Law', 4, 2, NULL),
(19, 'Administrative Law', 4, 2, NULL),
(20, 'Legal Research and Writing', 4, 2, NULL),
(21, 'Financial Accounting', 5, 3, NULL),
(22, 'Managerial Accounting', 5, 3, NULL),
(23, 'Corporate Finance', 4, 3, NULL),
(24, 'Investment Analysis', 4, 3, NULL),
(25, 'Principles of Marketing', 6, 3, NULL),
(26, 'Consumer Behavior', 6, 3, NULL),
(27, 'Human Resource Management', 7, 3, NULL),
(28, 'Organizational Behavior', 7, 3, NULL),
(29, 'Cooperative Management', 8, 3, NULL),
(30, 'Microeconomics', 9, 3, NULL),
(31, 'Introduction to Rural Development', 10, 4, NULL),
(32, 'Community Development Strategies', 10, 4, NULL),
(33, 'Sustainable Agriculture', 10, 4, NULL),
(34, 'Rural Project Planning', 10, 4, NULL),
(35, 'Disaster Risk Management', 11, 4, NULL),
(36, 'Emergency Response Operations', 11, 4, NULL),
(37, 'Environmental Impact Assessment', 11, 4, NULL),
(38, 'Climate Change Adaptation', 11, 4, NULL),
(39, 'Water and Sanitation Management', 10, 4, NULL),
(40, 'Food Security and Nutrition', 10, 4, NULL),
(41, 'Foundations of Education', 12, 5, NULL),
(42, 'Entrepreneurship in Education', 12, 5, NULL),
(43, 'Educational Psychology', 13, 5, NULL),
(44, 'Mathematics for Educators', 13, 5, NULL),
(45, 'Curriculum Development', 14, 5, NULL),
(46, 'Teaching Geography', 14, 5, NULL),
(47, 'Instructional Technology', 15, 5, NULL),
(48, 'Computer Literacy for Teachers', 15, 5, NULL),
(49, 'Assessment and Evaluation', 12, 5, NULL),
(50, 'Research Methods in Education', 12, 5, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Paid') DEFAULT 'Pending',
  `date_paid` date DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `student_id`, `amount`, `status`, `date_paid`) VALUES
(1, 1, '1000.00', 'Pending', '2025-10-02'),
(2, 2, '2000.00', 'Paid', '2025-10-02'),
(3, 3, '1500.00', 'Pending', '2025-10-02'),
(4, 4, '1800.00', 'Paid', '2025-10-02'),
(5, 5, '2200.00', 'Pending', '2025-10-02'),
(6, 6, '2500.00', 'Paid', '2025-10-02'),
(7, 7, '3000.00', 'Pending', '2025-10-02'),
(8, 8, '3500.00', 'Paid', '2025-10-02'),
(9, 9, '1200.00', 'Pending', '2025-10-02'),
(10, 10, '2700.00', 'Paid', '2025-10-02'),
(11, 11, '3100.00', 'Pending', '2025-10-02'),
(12, 12, '4000.00', 'Paid', '2025-10-02'),
(13, 13, '500.00', 'Pending', '2025-10-02'),
(14, 14, '2300.00', 'Paid', '2025-10-02'),
(15, 15, '1400.00', 'Pending', '2025-10-02'),
(16, 16, '1900.00', 'Paid', '2025-10-02'),
(17, 17, '2100.00', 'Pending', '2025-10-02'),
(18, 18, '3300.00', 'Paid', '2025-10-02'),
(19, 19, '2600.00', 'Pending', '2025-10-02'),
(20, 20, '2800.00', 'Paid', '2025-10-02'),
(21, 21, '3600.00', 'Pending', '2025-10-02'),
(22, 22, '3900.00', 'Paid', '2025-10-02'),
(23, 23, '4200.00', 'Pending', '2025-10-02'),
(24, 24, '4500.00', 'Paid', '2025-10-02'),
(25, 25, '4700.00', 'Pending', '2025-10-02'),
(26, 26, '4900.00', 'Paid', '2025-10-02'),
(27, 27, '5100.00', 'Pending', '2025-10-02'),
(28, 28, '5300.00', 'Paid', '2025-10-02'),
(29, 29, '5500.00', 'Pending', '2025-10-02'),
(30, 30, '5700.00', 'Paid', '2025-10-02'),
(31, 31, '5900.00', 'Pending', '2025-10-02'),
(32, 32, '6100.00', 'Paid', '2025-10-02'),
(33, 33, '6300.00', 'Pending', '2025-10-02'),
(34, 34, '6500.00', 'Paid', '2025-10-02');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;
CREATE TABLE IF NOT EXISTS `program` (
  `program_id` int NOT NULL AUTO_INCREMENT,
  `program_name` enum('Day','Evening','Weekend') NOT NULL,
  PRIMARY KEY (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`program_id`, `program_name`) VALUES
(1, 'Day'),
(2, 'Evening'),
(3, 'Weekend');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('Recovery','Account officer','Dean of ESM and Law','Dean of CIS and  ES','Finance','Coordinator','Librarian','register') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `dept_id` int DEFAULT NULL,
  `faculty_id` int DEFAULT NULL,
  PRIMARY KEY (`staff_id`),
  UNIQUE KEY `email` (`email`),
  KEY `dept_id` (`dept_id`),
  KEY `faculty_id` (`faculty_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `full_name`, `email`, `password`, `role`, `dept_id`, `faculty_id`) VALUES
(1, 'Mr.MNzayirambaho Justin', 'henrysogoya@gma', '$2y$10$jQRG0C6Aeqov/j/l7Brt9eBi0cKU1v0d4Xl4wGfzZ88mw6zdF511q', 'Dean of CIS and  ES', 3, 1),
(2, 'Mrs. Mukazitoni Bonifilida', 'henrysogoya@gmil.com', '$2y$10$EZjRqhdWZrUEFi3NcOb2me8CA5HsSv2BaHGVYSdbAmmLp0y6nOXge', 'Recovery', 5, 3),
(3, 'Dr SEMANA Javan', 'henrysogoya@gmail.com', '$2y$10$pq4vzMm3ndpJ1XFyflW4vOR1HFoMKclhEy.QRYgCleSwQ4ftx6jGW', 'Coordinator', 4, 2),
(4, 'Ms. Yvette Umugwaneza', 'henrysogoya@gmail.c', '$2y$10$e3TDxbLayYW.X7FiXfbzv.ZWs3BdI0ixJkETHjTNgpWlOgVgiDmLm', 'Librarian', 1, 1),
(5, 'Mr. Etienne IGIYIMANA', 'sogoyahenry@gmail.com', '$2y$10$K7obVtEVcgLKoDSUbaY0OuMFucRz7NDVLpKNe44w4BXQgp1yMhMd6', 'Dean of ESM and Law', 12, 5),
(6, 'Nkunzimana Thade', 'sogoahenry@gmail.com', '$2y$10$1o4pSxTfEmggZDLQz1ygwuGqrvl08TPljHoZGFjIhl8A.peX63nZm', 'register', 2, 4),
(7, 'USENGIMANA Richard', 'princedanny20011@gmail.com', '$2y$10$3kPPZwbkO3YTQT6oQh6XweFnOPOU3Y/t.WQ2Ww2aWkGhhFvJb/VYK', 'Account officer', NULL, NULL),
(8, 'Bunane ', 'niyogushimwaannabelle@gmail.com', '$2y$10$jASoVgQX2CGztvOudln.0e.nTXLErFrAgpC06mM/GrDcUnHMtSE1G', 'Recovery', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int NOT NULL AUTO_INCREMENT,
  `reg_number` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dept_id` int DEFAULT NULL,
  `faculty_id` int DEFAULT NULL,
  `program_id` int DEFAULT NULL,
  `access_token` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `reg_number` (`reg_number`),
  UNIQUE KEY `email` (`email`),
  KEY `faculty_id` (`faculty_id`),
  KEY `program_id` (`program_id`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `reg_number`, `full_name`, `email`, `dept_id`, `faculty_id`, `program_id`, `access_token`) VALUES
(1, '20100/2024', 'Ndayiragije Thierry', 'ndayiragijethierry11@gmail.com', 3, 1, 1, NULL),
(2, '20101/2024', 'John Nshimiyimana', 'john.nshim@example.com', 2, 1, 2, NULL),
(3, '20102/2024', 'Grace Mukamana', 'grace.muk@example.com', 1, 1, 3, NULL),
(4, '20103/2024', 'Eric Habimana', 'eric.hab@example.com', 4, 2, 1, NULL),
(5, '20104/2024', 'Diane Umutoni', 'diane.umut@example.com', 4, 2, 2, NULL),
(6, '20105/2024', 'Patrick Mugisha', 'patrick.mug@example.com', 5, 3, 3, NULL),
(7, '20106/2024', 'Sylvie Uwamahoro', 'sylvie.uwa@example.com', 6, 3, 1, NULL),
(8, '20107/2024', 'Claude Bizimana', 'claude.biz@example.com', 7, 3, 2, NULL),
(9, '20108/2024', 'Esther Ingabire', 'esther.inga@example.com', 8, 3, 3, NULL),
(10, '20109/2024', 'Paul Rutikanga', 'paul.rut@example.com', 9, 3, 1, NULL),
(11, '20110/2024', 'Sandra Akimana', 'sandra.aki@example.com', 10, 4, 2, NULL),
(12, '20111/2024', 'Emmanuel Hakizimana', 'emmanuel.hak@example.com', 11, 4, 3, NULL),
(13, '20112/2024', 'Yvette Uwimana', 'yvette.uwa@example.com', 10, 4, 1, NULL),
(14, '20113/2024', 'Jean Bosco Tuyisenge', 'bosco.tuyi@example.com', 12, 5, 2, NULL),
(15, '20114/2024', 'Florence Umugwaneza', 'florence.umu@example.com', 13, 5, 3, NULL),
(16, '20115/2024', 'Samuel Niyonzima', 'samuel.niyo@example.com', 14, 5, 1, NULL),
(17, '20116/2024', 'Ange Imanishimwe', 'ange.ima@example.com', 15, 5, 2, NULL),
(18, '20117/2024', 'Oliver Nkurunziza', 'oliver.nku@example.com', 3, 1, 3, NULL),
(19, '20118/2024', 'Lydia Nyirahabimana', 'lydia.nyi@example.com', 2, 1, 1, NULL),
(20, '20119/2024', 'David Iradukunda', 'david.ira@example.com', 1, 1, 2, NULL),
(21, '21924/2023', 'BATAMURIZA BEATRICE', 'batamurizab161@gmail.com', 2, 1, 1, NULL),
(22, '21662/2023', 'Kamariza Christine', 'christinekamariza4@gmail.com', 2, 1, 1, NULL),
(23, '30223/2025', 'Niyikiza GAUDANCE', 'niyikizagogo@gmail.com', 2, 1, 1, NULL),
(27, '21302/2023', 'Niyokwizerwajosirine', 'joserineniyokwizerwa70@gmail.co', 5, 3, 2, NULL),
(28, '21322/2023', 'Nyiramugisha folorence', 'nyiramugishafolorence642@gmail.co', 5, 3, 2, NULL),
(29, '21786/2023', 'Uwimana Rachel', 'racheuwimana472@gmail.com', 5, 3, 2, NULL),
(30, '31519/2025', 'Namara Rachel', 'nmrrachel@gmail.com', 15, 5, 3, NULL),
(31, '31176/2025', 'Ingabire cyntia', 'cyntiaingabire562@gmail.com', 15, 5, 3, NULL),
(32, '31134/2025', 'Umutesiemelyne', 'emeyneumutesi61@gmai.com', 15, 5, 3, NULL),
(33, '22890/2023', 'MIZERO MIGNONI', 'mizeromignoni@gmail.com', 4, 2, 2, NULL),
(34, '22535/2023', 'Kabanyanacecile', 'kabanyanacecile5@gmail.com', 4, 2, 3, NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assiment`
--
ALTER TABLE `assiment`
  ADD CONSTRAINT `assiment_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`);

--
-- Constraints for table `clearance`
--
ALTER TABLE `clearance`
  ADD CONSTRAINT `clearance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`),
  ADD CONSTRAINT `clearance_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `department_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `module`
--
ALTER TABLE `module`
  ADD CONSTRAINT `module_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`);

--
-- Constraints for table `program`
--
ALTER TABLE `program`
  ADD CONSTRAINT `program_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
