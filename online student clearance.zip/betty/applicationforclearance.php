<?php 
session_start();
require_once 'db_connect.php'; // PDO connection

// 1️⃣ Make sure student is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// 2️⃣ Fetch student details with program, department, faculty
$stmt = $pdo->prepare("
    SELECT s.student_id, s.reg_number, s.full_name, s.email, 
           p.program_name, d.dept_name, f.faculty_name
    FROM Student s
    LEFT JOIN Program p ON s.program_id = p.program_id
    LEFT JOIN Department d ON s.dept_id = d.dept_id
    LEFT JOIN Faculty f ON s.faculty_id = f.faculty_id
    WHERE s.student_id = ?
");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

// 3️⃣ Define clearance categories and corresponding staff roles
$categories = [
    'Payment'      => 'Finance',
    'Modules'      => 'HOD',
    'Library'      => 'Librarian',
    'Education'    => 'Dean',
    'Registration' => 'Register'
];

$categorySelected = $_POST['category'] ?? null;
$categoryMessage = "";
$staffMembers = [];
$clearances = [];

// 4️⃣ If a valid category is selected
if ($categorySelected && isset($categories[$categorySelected])) {
    $staffRole = $categories[$categorySelected];

    // Get staff in this category
    $staffStmt = $pdo->prepare("SELECT staff_id, full_name FROM Staff WHERE role = ?");
    $staffStmt->execute([$staffRole]);
    $staffMembers = $staffStmt->fetchAll(PDO::FETCH_ASSOC);

    // Get clearance status for this student in this category
    $clearanceStmt = $pdo->prepare("
        SELECT c.status, c.remarks, c.reason, s.full_name AS staff_name
        FROM Clearance c
        JOIN Staff s ON c.staff_id = s.staff_id
        WHERE c.student_id = ? AND s.role = ?
        ORDER BY c.updated_at DESC
    ");
    $clearanceStmt->execute([$student_id, $staffRole]);
    $clearances = $clearanceStmt->fetchAll(PDO::FETCH_ASSOC);

    $categoryMessage = "📌 Clearance info for <strong>$categorySelected</strong>:";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Clearance Portal - Let's Get You Cleared! 🎓</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --light: #f8f9fa;
            --dark: #212529;
            --gradient: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding-bottom: 2rem;
        }
        
        .header-card {
            background: var(--gradient);
            color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 2rem;
            position: relative;
        }
        
        .header-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="%23ffffff" fill-opacity="0.1" d="M0,96L48,112C96,128,192,160,288,186.7C384,213,480,235,576,213.3C672,192,768,128,864,128C960,128,1056,192,1152,197.3C1248,203,1344,149,1392,122.7L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>');
            background-size: cover;
        }
        
        .content-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .welcome-text {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .student-info {
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
            padding: 1.5rem;
            backdrop-filter: blur(10px);
            position: relative;
            z-index: 1;
        }
        
        .category-card {
            transition: all 0.3s ease;
            border: none;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 1rem;
        }
        
        .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .category-header {
            background: var(--gradient);
            color: white;
            padding: 1rem;
            font-weight: 600;
        }
        
        .staff-item {
            border-left: 4px solid var(--primary);
            padding-left: 1rem;
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
        }
        
        .staff-item:hover {
            border-left: 4px solid var(--success);
            background-color: #f8f9fa;
            padding-left: 1.2rem;
        }
        
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 600;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-approved {
            background-color: #d1edff;
            color: #0c5460;
        }
        
        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }
        
        .btn-request {
            background: var(--gradient);
            border: none;
            border-radius: 50px;
            padding: 0.5rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-request:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.4);
        }
        
        .progress-container {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 2rem;
        }
        
        .progress-title {
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--primary);
        }
        
        .category-select {
            border-radius: 10px;
            padding: 0.75rem;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        
        .category-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(67, 97, 238, 0.25);
        }
        
        .celebrate {
            animation: celebrate 1s ease;
        }
        
        @keyframes celebrate {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .icon-circle {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
        }
        
        /* Logout button positioning */
        .logout-container {
            position: absolute;
            top: 20px;
            right: 20px;
            z-index: 10;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <!-- Header Card with Welcome Message -->
    <div class="header-card position-relative">
        <!-- Logout Button - Properly Positioned -->
        <div class="logout-container">
            <a href="index.php" class="btn btn-danger btn-sm">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
        
        <div class="card-body p-4 p-md-5">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="welcome-text">Hello, <?= htmlspecialchars($student['full_name']) ?>! 👋</h1>
                    <p class="lead mb-0">Let's get you cleared for an amazing academic journey! 🚀</p>
                </div>
                <div class="col-md-4 text-center">
                    <div class="icon-circle mx-auto">
                        <i class="fas fa-graduation-cap fa-2x"></i>
                    </div>
                </div>
            </div>
            
            <div class="student-info mt-4">
                <div class="row">
                    <div class="col-md-3">
                        <strong><i class="fas fa-id-card me-2"></i>Reg. Number:</strong><br>
                        <?= htmlspecialchars($student['reg_number']) ?>
                    </div>
                    <div class="col-md-3">
                        <strong><i class="fas fa-book me-2"></i>Program:</strong><br>
                        <?= htmlspecialchars($student['program_name']) ?>
                    </div>
                    <div class="col-md-3">
                        <strong><i class="fas fa-building me-2"></i>Department:</strong><br>
                        <?= htmlspecialchars($student['dept_name']) ?>
                    </div>
                    <div class="col-md-3">
                        <strong><i class="fas fa-university me-2"></i>Faculty:</strong><br>
                        <?= htmlspecialchars($student['faculty_name']) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- The rest of your content remains exactly the same -->
    <!-- Progress Overview -->
    <div class="progress-container">
        <h4 class="progress-title"><i class="fas fa-tasks me-2"></i>Your Clearance Progress</h4>
        <div class="progress mb-3" style="height: 20px;">
            <div class="progress-bar bg-success" role="progressbar" style="width: 25%;" 
                 aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25% Complete</div>
        </div>
        <p class="mb-0 text-muted">You're making great progress! Keep it up! 💪</p>
    </div>

    <!-- Category Selection -->
    <div class="content-card">
        <h4 class="mb-3"><i class="fas fa-filter me-2"></i>Select Clearance Category</h4>
        <form method="post">
            <div class="row">
                <div class="col-md-8">
                    <select class="form-select category-select" name="category" id="category" onchange="this.form.submit()">
                        <option value="">-- Choose a category to check your clearance status --</option>
                        <?php foreach ($categories as $cat => $role): ?>
                            <option value="<?= $cat ?>" <?= $categorySelected === $cat ? 'selected' : '' ?>>
                                <?= $cat ?> Clearance (<?= $role ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-request w-100 text-white">
                        <i class="fas fa-search me-2"></i>Check Status
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Staff & Clearance Info -->
    <?php if ($categorySelected): ?>
        <div class="content-card celebrate">
            <h4 class="mb-4">
                <i class="fas fa-info-circle me-2"></i>
                <?= $categoryMessage ?>
            </h4>

            <?php if ($staffMembers): ?>
                <div class="row">
                    <?php foreach ($staffMembers as $staff): ?>
                        <?php
                            $c = array_filter($clearances, fn($cl) => $cl['staff_name'] === $staff['full_name']);
                            $c = array_values($c)[0] ?? null;
                            $status = $c ? $c['status'] : 'Pending';
                            $statusClass = 'status-pending';
                            
                            if ($status === 'Approved') {
                                $statusClass = 'status-approved';
                            } elseif ($status === 'Completed') {
                                $statusClass = 'status-completed';
                            }
                        ?>
                        
                        <div class="col-md-6 mb-4">
                            <div class="category-card">
                                <div class="category-header">
                                    <i class="fas fa-user-tie me-2"></i><?= htmlspecialchars($staff['full_name']) ?>
                                </div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <span>Status:</span>
                                        <span class="status-badge <?= $statusClass ?>">
                                            <?= $status ?>
                                            <?php if ($status === 'Completed'): ?>
                                                <i class="fas fa-check ms-1"></i>
                                            <?php elseif ($status === 'Approved'): ?>
                                                <i class="fas fa-thumbs-up ms-1"></i>
                                            <?php else: ?>
                                                <i class="fas fa-clock ms-1"></i>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <strong>Remarks:</strong><br>
                                        <?= $c ? htmlspecialchars($c['remarks']) : 'Waiting for review 📝' ?>
                                    </div>

                                    <!-- Request Clearance Button -->
                                    <?php if (!$c || $c['status'] === 'Pending'): ?>
                                        <form method="post" action="request_clearance.php">
                                            <input type="hidden" name="staff_id" value="<?= $staff['staff_id'] ?>">
                                            <input type="hidden" name="category" value="<?= $categorySelected ?>">
                                            <button type="submit" class="btn btn-request w-100 text-white">
                                                <i class="fas fa-paper-plane me-2"></i>Request Clearance
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <div class="text-center text-success">
                                            <i class="fas fa-check-circle fa-2x mb-2"></i>
                                            <p class="mb-0">Clearance request submitted! 🎉</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning text-center">
                    <i class="fas fa-exclamation-triangle fa-2x mb-3"></i>
                    <h5>No staff found for this category</h5>
                    <p class="mb-0">Please contact administration for assistance.</p>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <!-- Default view when no category is selected -->
        <div class="content-card text-center">
            <i class="fas fa-clipboard-list fa-4x text-primary mb-3"></i>
            <h4>Ready to check your clearance status?</h4>
            <p class="text-muted">Select a category above to see your progress and request clearances!</p>
        </div>
    <?php endif; ?>
    
    <!-- Footer -->
    <div class="text-center mt-4 text-muted">
        <p>Need help? Contact the administration office. <i class="fas fa-hands-helping ms-1"></i></p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Add celebration effect when status is completed
    document.addEventListener('DOMContentLoaded', function() {
        const statusBadges = document.querySelectorAll('.status-badge');
        statusBadges.forEach(badge => {
            if (badge.textContent.includes('Completed')) {
                badge.classList.add('celebrate');
            }
        });
    });
</script>
</body>
</html>