<?php
session_start();
require_once 'db_connect.php';

// Check if user is logged in as Finance
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Finance') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_POST['action'] === 'search' && isset($_POST['reg_number'])) {
    $regNumber = trim($_POST['reg_number']);
    
    try {
        $stmt = $pdo->prepare("
            SELECT s.student_id, s.full_name, s.reg_number, s.email, 
                   s.faculty_id, s.dept_id, s.program_id,
                   f.faculty_name, d.dept_name, p.program_name
            FROM student s
            LEFT JOIN faculty f ON s.faculty_id = f.faculty_id
            LEFT JOIN department d ON s.dept_id = d.dept_id
            LEFT JOIN program p ON s.program_id = p.program_id
            WHERE s.reg_number LIKE ?
            ORDER BY s.full_name ASC
        ");
        
        $searchTerm = '%' . $regNumber . '%';
        $stmt->execute([$searchTerm]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $students
        ]);
        
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request'
    ]);
}
?>