<?php
session_start();
require 'vendor/autoload.php'; // Include PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Clearance";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$email = $_POST['email'];
$reg_number = $_POST['reg_number'];

// Verify if student exists
$sql = "SELECT * FROM Student WHERE email = ? AND reg_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $email, $reg_number);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Generate OTP
    $otp = rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_email'] = $email;
    $_SESSION['otp_time'] = time();
    
    // Send OTP via email using PHPMailer
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username   = 'sogoyahenry@gmail.com';
        $mail->Password   = 'rxzh emte duin ikox'; // App password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        // Recipients
        $mail->setFrom('sogoyahenry@gmail.com', 'Clearance Portal');
        $mail->addAddress($email);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP for Clearance Portal Login';
        $mail->Body = "Your OTP for login is: <b>$otp</b><br>This OTP will expire in 10 minutes.";
        $mail->AltBody = "Your OTP for login is: $otp. This OTP will expire in 10 minutes.";
        
        $mail->send();
        echo json_encode(['success' => true, 'message' => 'OTP sent successfully']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to send OTP: ' . $mail->ErrorInfo]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid email or registration number']);
}

$conn->close();
?>