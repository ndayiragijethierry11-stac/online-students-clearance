<?php  
session_start();
require_once 'db_connect.php'; // PDO connection

// Load PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

// ✅ Ensure Librarian staff is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Dean of CIS and  ES') {
    header("Location: index.php");
    exit();
}

// ✅ Fetch pending clearance requests
$staff_id = $_SESSION['staff_id'] ?? 1; // dynamically use session staff_id

// ✅ Fetch pending clearance requests for this staff
$pendingClearances = $pdo->prepare("
    SELECT c.clearance_id, c.student_id, c.reason, c.status, c.updated_at,
           s.full_name AS student_name, s.reg_number, s.faculty_id, s.dept_id, s.program_id,
           st.full_name AS staff_name
    FROM clearance c
    JOIN student s ON c.student_id = s.student_id
    JOIN staff st ON c.staff_id = st.staff_id
    WHERE c.status = 'Pending' AND c.staff_id = ?
    ORDER BY c.updated_at DESC
");
$pendingClearances->execute([$staff_id]);
$pendingClearances = $pendingClearances->fetchAll(PDO::FETCH_ASSOC);

// ✅ Fetch completed/reviewed clearances for this staff
$completedClearances = $pdo->prepare("
    SELECT c.clearance_id, c.student_id, c.reason, c.status, c.remarks, c.updated_at,
           s.full_name AS student_name, s.reg_number,
           st.full_name AS staff_name
    FROM clearance c
    JOIN student s ON c.student_id = s.student_id
    JOIN staff st ON c.staff_id = st.staff_id
    WHERE c.status IN ('Cleared','Rejected') AND c.staff_id = ?
    ORDER BY c.updated_at DESC
");
$completedClearances->execute([$staff_id]);
$completedClearances = $completedClearances->fetchAll(PDO::FETCH_ASSOC);

// ✅ Fetch student records (system-wide, not filtered)
$students = $pdo->query("
    SELECT s.student_id, s.full_name, s.reg_number, s.email, 
           s.faculty_id, s.dept_id, s.program_id,
           f.faculty_name, d.dept_name, p.program_name
    FROM student s
    LEFT JOIN faculty f ON s.faculty_id = f.faculty_id
    LEFT JOIN department d ON s.dept_id = d.dept_id
    LEFT JOIN program p ON s.program_id = p.program_id
    ORDER BY s.full_name ASC
")->fetchAll(PDO::FETCH_ASSOC);

// ✅ Fetch coordinator assignments only for this staff
$assignmentsStmt = $pdo->prepare("
    SELECT a.assiment_id, a.title, a.description, a.status, 
           a.updated_at, a.due_date, 
           st.full_name AS student_name, st.reg_number,
           sf.full_name AS staff_name
    FROM assiment a
    LEFT JOIN student st ON a.student_id = st.student_id
    LEFT JOIN staff sf ON a.staff_id = sf.staff_id
    WHERE a.staff_id = ?
    ORDER BY a.assiment_id DESC
");
$assignmentsStmt->execute([$staff_id]);
$assignments = $assignmentsStmt->fetchAll(PDO::FETCH_ASSOC);

// ✅ Handle clearance approval/rejection
if (isset($_POST['update_clearance'])) {
    $clearance_id = $_POST['clearance_id'];
    $status = $_POST['update_clearance'] === 'approve' ? 'Cleared' : 'Rejected';
    $remarks = $_POST['remarks'];
    
    $pdo->beginTransaction();
    try {
        // Update clearance
        $stmt = $pdo->prepare("UPDATE clearance SET status = ?, remarks = ?, updated_at = NOW() WHERE clearance_id = ? AND staff_id = ?");
        $stmt->execute([$status, $remarks, $clearance_id, $staff_id]);

        // Fetch student info
        $stmt = $pdo->prepare("
            SELECT c.student_id, c.faculty_id, c.dept_id, s.full_name, s.email 
            FROM clearance c
            JOIN student s ON c.student_id = s.student_id
            WHERE c.clearance_id = ? AND c.staff_id = ?
        ");
        $stmt->execute([$clearance_id, $staff_id]);
        $clearance_data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($clearance_data) {
            $student_id = $clearance_data['student_id'];
            $faculty_id = $clearance_data['faculty_id'];
            $dept_id = $clearance_data['dept_id'];
            $student_name = $clearance_data['full_name'];
            $student_email = $clearance_data['email'];
            
            // Update assignment table
            $assignment_status = ($status === 'Cleared') ? 'Cleared' : 'Rejected';
            $stmt = $pdo->prepare("
                UPDATE assiment 
                SET status = ?, due_date = NOW(), updated_at = NOW() 
                WHERE student_id = ? AND faculty_id = ? AND dept_id = ? AND staff_id = ?
            ");
            $stmt->execute([$assignment_status, $student_id, $faculty_id, $dept_id, $staff_id]);

            // Send email notification
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'sogoyahenry@gmail.com';
                $mail->Password   = 'rxzh emte duin ikox'; // app password
                $mail->SMTPSecure = 'tls';
                $mail->Port       = 587;

                $mail->setFrom('sogoyahenry@gmail.com', 'Librarian Department');
                $mail->addAddress($student_email, $student_name);

                $mail->isHTML(true);
                $mail->Subject = "Library Clearance Status Update";
                $mail->Body    = "
                    <p>Dear <strong>{$student_name}</strong>,</p>
                    <p>Your library clearance request (ID: {$clearance_id}) has been <strong>{$status}</strong>.</p>
                    <p><b>Remarks:</b> {$remarks}</p>
                    <p>Regards,<br>Library Department</p>
                ";
                $mail->send();
            } catch (Exception $e) {
                error_log("Email could not be sent: {$mail->ErrorInfo}");
            }
        }

        $pdo->commit();
        $_SESSION['message'] = "✅ Clearance updated & student notified.";
        $_SESSION['message_type'] = 'success';
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['message'] = "❌ Error updating records: " . $e->getMessage();
        $_SESSION['message_type'] = 'error';
    }

    header("Location: registration.php");
    exit();
}

// ✅ Handle appointment setting
if (isset($_POST['set_appointment'])) {
    $clearance_id = $_POST['clearance_id'];
    $appointment_date = $_POST['appointment_date'];
    $remarks = $_POST['remarks'] ?? '';
    
    try {
        $stmt = $pdo->prepare("UPDATE clearance SET appointment_date = ?, remarks = ?, updated_at = NOW() WHERE clearance_id = ? AND staff_id = ?");
        $stmt->execute([$appointment_date, $remarks, $clearance_id, $staff_id]);
        
        $_SESSION['message'] = "✅ Appointment date set successfully.";
        $_SESSION['message_type'] = 'success';
    } catch (Exception $e) {
        $_SESSION['message'] = "❌ Error setting appointment: " . $e->getMessage();
        $_SESSION['message_type'] = 'error';
    }
    
    header("Location: registration.php");
    exit();
}

// ✅ Handle logout
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HOD Clearance System</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: "Inter", Arial, sans-serif; }
body { display: flex; min-height: 100vh; background: #f4f6f9; color: #333; }

/* Sidebar */
.sidebar { width: 260px; height: 100vh; background: #1e3a8a; color: #fff; position: fixed; top: 0; left: 0; display: flex; flex-direction: column; justify-content: space-between; transition: all 0.3s ease; }
.sidebar-header { text-align: center; padding: 25px 15px; border-bottom: 1px solid rgba(255,255,255,0.2); }
.sidebar-header h2 { font-size: 22px; margin-top: 10px; font-weight: 600; }
.sidebar-menu { flex: 1; overflow-y: auto; }
.menu-item, .submenu-item { padding: 14px 25px; display: flex; align-items: center; cursor: pointer; transition: background 0.3s ease; font-size: 16px; }
.menu-item i, .submenu-item i { margin-right: 12px; font-size: 18px; }
.menu-item:hover, .submenu-item:hover, .menu-item.active { background: #2563eb; }
.submenu { display: none; flex-direction: column; background: #1e40af; }
.menu-item.has-submenu.active + .submenu { display: flex; }

/* User Profile */
.user-profile { padding: 20px; background: #1e40af; text-align: center; }
.user-avatar { width: 55px; height: 55px; border-radius: 50%; background: #2563eb; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; color: #fff; font-size: 22px; margin-bottom: 10px; }
.user-details h4 { font-size: 16px; font-weight: 600; }
.user-details span { font-size: 14px; color: #cbd5e1; }
.logout-btn { width: 100%; padding: 12px; background: #dc2626; border: none; border-radius: 8px; color: #fff; cursor: pointer; transition: background 0.3s ease; }
.logout-btn:hover { background: #b91c1c; }

/* Main Content */
.main-content { margin-left: 260px; padding: 30px; width: calc(100% - 260px); }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
.header h1 { font-size: 26px; color: #1e3a8a; font-weight: 700; }
.current-date { font-size: 14px; color: #555; }

/* Messages */
.message { padding: 14px 18px; border-radius: 12px; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; font-size: 15px; }
.message-success { background: #dcfce7; color: #166534; }
.message-error { background: #fee2e2; color: #991b1b; }

/* Stats Cards */
.stats-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 25px; margin-bottom: 35px; }
.stat-card { background: #fff; border-radius: 18px; padding: 25px; text-align: center; box-shadow: 0 5px 20px rgba(0,0,0,0.05); transition: transform 0.3s ease, box-shadow 0.3s ease; cursor: pointer; }
.stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
.stat-icon { font-size: 32px; margin-bottom: 14px; }
.stat-value { font-size: 28px; font-weight: 700; }
.stat-label { font-size: 16px; color: #555; }
.stat-card.pending .stat-icon { color: #f59e0b; }
.stat-card.completed .stat-icon { color: #16a34a; }
.stat-card.rejected .stat-icon { color: #dc2626; }
.stat-card.total .stat-icon { color: #2563eb; }

/* Form Cards */
.form-card { background: #fff; padding: 25px; border-radius: 18px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); margin-bottom: 25px; }
.form-card-header { margin-bottom: 20px; font-size: 20px; font-weight: 600; color: #1e3a8a; display: flex; align-items: center; gap: 10px; }
.form-card-body { display: flex; flex-direction: column; gap: 15px; }

/* Form Groups */
.form-group { margin-bottom: 15px; }
.form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px; }
.form-control { width: 100%; padding: 12px 15px; border: 1px solid #d1d5db; border-radius: 10px; font-size: 15px; transition: all 0.3s ease; }
.form-control:focus { outline: none; border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }
.form-select { width: 100%; padding: 12px 15px; border: 1px solid #d1d5db; border-radius: 10px; font-size: 15px; background: white; }
.form-textarea { min-height: 100px; resize: vertical; }

/* Form Layouts */
.form-row { display: flex; gap: 15px; margin-bottom: 15px; }
.form-row .form-group { flex: 1; margin-bottom: 0; }
.form-actions { display: flex; gap: 10px; margin-top: 20px; }
.form-compact { display: flex; gap: 10px; align-items: flex-end; flex-wrap: wrap; }
.form-compact .form-group { margin-bottom: 0; flex: 1; min-width: 150px; }

/* Buttons */
.btn { padding: 12px 20px; border: none; border-radius: 10px; cursor: pointer; font-size: 14px; font-weight: 600; transition: all 0.3s ease; display: inline-flex; align-items: center; gap: 8px; }
.btn-sm { padding: 8px 16px; font-size: 13px; }
.btn-success { background: #16a34a; color: #fff; }
.btn-success:hover { background: #138a35; }
.btn-danger { background: #dc2626; color: #fff; }
.btn-danger:hover { background: #b91c1c; }
.btn-primary { background: #2563eb; color: #fff; }
.btn-primary:hover { background: #1d4ed8; }
.btn-secondary { background: #6b7280; color: #fff; }
.btn-secondary:hover { background: #4b5563; }

/* Status Badges */
.status-badge { padding: 6px 14px; border-radius: 15px; font-size: 13px; font-weight: 600; display: inline-block; text-align: center; }
.status-pending { background: #fef3c7; color: #92400e; }
.status-approved, .status-completed { background: #dcfce7; color: #166534; }
.status-rejected { background: #fee2e2; color: #991b1b; }

/* Request Items */
.request-item { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin-bottom: 15px; }
.request-header { display: flex; justify-content: between; align-items: center; margin-bottom: 15px; }
.request-title { font-weight: 600; color: #1e3a8a; font-size: 16px; }
.request-meta { display: flex; gap: 15px; margin-bottom: 15px; font-size: 14px; color: #6b7280; }
.request-meta-item { display: flex; align-items: center; gap: 5px; }
.request-actions { display: flex; gap: 10px; flex-wrap: wrap; }

/* Assignment Cards */
.assignment-card { background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 12px; padding: 20px; margin-bottom: 15px; }
.assignment-card.completed { background: #f0fdf4; border-color: #bbf7d0; }
.assignment-card.rejected { background: #fef2f2; border-color: #fecaca; }

/* Search Box */
.search-container { margin-bottom: 20px; }
.search-box { position: relative; max-width: 400px; }
.search-input { width: 100%; padding: 12px 45px 12px 15px; border: 1px solid #ddd; border-radius: 10px; font-size: 14px; transition: all 0.3s ease; }
.search-input:focus { outline: none; border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }
.search-icon { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: #6b7280; }

/* Tables (Only for Student Records) */
.table-container { background: #fff; padding: 25px; border-radius: 18px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); margin-bottom: 35px; overflow-x: auto; }
.table-title { margin-bottom: 20px; font-size: 20px; font-weight: 600; color: #1e3a8a; }
table { width: 100%; border-collapse: collapse; min-width: 800px; }
thead { background: #f3f4f6; }
th, td { padding: 14px 18px; border-bottom: 1px solid #e5e7eb; text-align: left; font-size: 15px; }
tr:hover { background: #f9fafb; }

/* Empty States */
.empty-state { text-align: center; padding: 40px 20px; color: #6b7280; }
.empty-state i { font-size: 48px; margin-bottom: 15px; color: #d1d5db; }
.empty-state h4 { margin-bottom: 10px; color: #374151; }

/* Hide all content sections by default */
.content-section { display: none; }
.content-section.active { display: block; }

/* Responsive */
@media (max-width: 992px) { 
    .sidebar { width: 220px; } 
    .main-content { margin-left: 220px; padding: 25px; } 
    .form-row { flex-direction: column; }
}
@media (max-width: 768px) { 
    body { flex-direction: column; } 
    .sidebar { width: 100%; height: auto; position: relative; } 
    .main-content { margin-left: 0; width: 100%; padding: 15px; } 
    .stats-cards { grid-template-columns: 1fr 1fr; gap: 15px; } 
    .request-header { flex-direction: column; align-items: flex-start; gap: 10px; }
    .request-actions { width: 100%; justify-content: flex-start; }
}
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header"><i class="fas fa-book"></i><h2>HOD Dashboard</h2></div>
    <div class="sidebar-menu">
        <div class="menu-item active" data-target="dashboard"><i class="fas fa-tachometer-alt"></i><span class="menu-text">Dashboard</span></div>
        <div class="menu-item has-submenu"><i class="fas fa-clipboard-check"></i><span class="menu-text">Clearance Requests</span><i class="fas fa-chevron-down ml-auto"></i></div>
        <div class="submenu">
            <div class="submenu-item" data-target="pending-requests"><i class="fas fa-clock"></i><span>Pending Requests</span></div>
            <div class="submenu-item" data-target="completed-requests"><i class="fas fa-check-circle"></i><span>Completed Requests</span></div>
        </div>
        <div class="menu-item" data-target="students"><i class="fas fa-user-graduate"></i><span class="menu-text">Student Records</span></div>
        <div class="menu-item" data-target="coordinator-assignment"><i class="fas fa-tasks"></i><span>Coordinator Assignment</span></div>
        <div class="menu-item" data-target="financial-reports"><i class="fas fa-chart-bar"></i><span>Reports</span></div>
    </div>
    <div class="user-profile">
        <div class="user-info">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['full_name'] ?? 'L',0,1)) ?></div>
            <div class="user-details"><h4><?= $_SESSION['full_name'] ?? 'Librarian' ?></h4><span>CIS and ES</span></div>
        </div>
        <form method="POST"><button type="submit" name="logout" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</button></form>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="header">
        <h1><i class="fas fa-book"></i> HOD Clearance Dashboard</h1>
        <div class="header-actions"><span class="current-date"><i class="fas fa-calendar"></i> <?= date('F j, Y') ?></span></div>
    </div>

    <!-- Messages -->
    <?php if(isset($_SESSION['message'])): ?>
        <div class="message <?= $_SESSION['message_type']==='error'?'message-error':'message-success' ?>">
            <i class="fas <?= $_SESSION['message_type']==='error'?'fa-exclamation-circle':'fa-check-circle' ?>"></i>
            <?= $_SESSION['message']; unset($_SESSION['message'], $_SESSION['message_type']); ?>
        </div>
    <?php endif; ?>

    <!-- Dashboard Section -->
    <div id="dashboard" class="content-section active">
        <div class="stats-cards">
            <div class="stat-card total" onclick="showSection('dashboard')">
                <div class="stat-icon total"><i class="fas fa-file-invoice"></i></div>
                <div class="stat-value"><?= count($pendingClearances)+count($completedClearances) ?></div>
                <div class="stat-label">Total Clearance Requests</div>
            </div>
            <div class="stat-card pending" onclick="showSection('pending-requests')">
                <div class="stat-icon pending"><i class="fas fa-clock"></i></div>
                <div class="stat-value"><?= count($pendingClearances) ?></div>
                <div class="stat-label">Pending Review</div>
            </div>
            <div class="stat-card completed" onclick="showSection('completed-requests')">
                <div class="stat-icon completed"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value">
                    <?= count(array_filter($completedClearances,fn($c)=>in_array($c['status'],['Cleared']))) ?>
                </div>
                <div class="stat-label">Approved Requests</div>
            </div>
            <div class="stat-card rejected" onclick="showSection('completed-requests')">
                <div class="stat-icon rejected"><i class="fas fa-times-circle"></i></div>
                <div class="stat-value"><?= count(array_filter($completedClearances,fn($c)=>$c['status']==='Rejected')) ?></div>
                <div class="stat-label">Rejected Requests</div>
            </div>
        </div>
    </div>

    <!-- Pending Requests -->
    <div id="pending-requests" class="content-section">
        <div class="form-card">
            <div class="form-card-header">
                <i class="fas fa-clock"></i>
                <h3>Pending Clearance Requests</h3>
            </div>
            
            <!-- Search Box -->
            <div class="search-container">
                <div class="search-box">
                    <input type="text" id="pendingSearch" class="search-input" placeholder="Search by registration number or student name...">
                    <i class="fas fa-search search-icon"></i>
                </div>
            </div>
            
            <div class="form-card-body" id="pendingResults">
                <?php foreach($pendingClearances as $clearance): ?>
                    <div class="request-item pending-request" data-reg="<?= htmlspecialchars(strtolower($clearance['reg_number'])) ?>" data-name="<?= htmlspecialchars(strtolower($clearance['student_name'])) ?>">
                        <div class="request-header">
                            <div class="request-title">
                                Clearance Request #<?= $clearance['clearance_id'] ?> - <?= htmlspecialchars($clearance['student_name']) ?>
                            </div>
                            <span class="status-badge status-pending"><?= $clearance['status'] ?></span>
                        </div>
                        
                        <div class="request-meta">
                            <div class="request-meta-item">
                                <i class="fas fa-id-card"></i>
                                <span><?= htmlspecialchars($clearance['reg_number']) ?></span>
                            </div>
                            <div class="request-meta-item">
                                <i class="fas fa-calendar"></i>
                                <span><?= date('M j, Y', strtotime($clearance['updated_at'])) ?></span>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Reason for Clearance</label>
                            <div class="form-control" style="background: #f9fafb;"><?= htmlspecialchars($clearance['reason']) ?></div>
                        </div>
                        
                        <form method="POST" class="clearance-form">
                            <input type="hidden" name="clearance_id" value="<?= $clearance['clearance_id'] ?>">
                            
                            <div class="form-compact">
                                <div class="form-group">
                                    <label>Remarks</label>
                                    <input type="text" name="remarks" class="form-control" placeholder="Enter remarks..." required>
                                </div>
                                
                                <div class="form-group">
                                    <label>Appointment Date</label>
                                    <input type="date" name="appointment_date" class="form-control" min="<?= date('Y-m-d') ?>">
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="update_clearance" value="approve" class="btn btn-success">
                                    <i class="fas fa-check"></i> Approve
                                </button>
                                <button type="submit" name="update_clearance" value="reject" class="btn btn-danger">
                                    <i class="fas fa-times"></i> Reject
                                </button>
                                <button type="submit" name="set_appointment" value="set" class="btn btn-primary">
                                    <i class="fas fa-calendar"></i> Set Appointment
                                </button>
                            </div>
                        </form>
                    </div>
                <?php endforeach; ?>
                
                <?php if(empty($pendingClearances)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h4>No Pending Clearance Requests</h4>
                        <p>There are currently no pending clearance requests awaiting your review.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Completed Requests -->
    <div id="completed-requests" class="content-section">
        <div class="form-card">
            <div class="form-card-header">
                <i class="fas fa-check-circle"></i>
                <h3>Completed Clearance Requests</h3>
            </div>
            
            <div class="form-card-body">
                <?php foreach($completedClearances as $clearance): ?>
                    <?php 
                    $statusClass = 'status-pending';
                    if(in_array($clearance['status'], ['Cleared'])) $statusClass = 'status-approved';
                    elseif($clearance['status'] === 'Rejected') $statusClass = 'status-rejected';
                    ?>
                    
                    <div class="request-item">
                        <div class="request-header">
                            <div class="request-title">
                                Request #<?= $clearance['clearance_id'] ?> - <?= htmlspecialchars($clearance['student_name']) ?>
                            </div>
                            <span class="status-badge <?= $statusClass ?>"><?= $clearance['status'] ?></span>
                        </div>
                        
                        <div class="request-meta">
                            <div class="request-meta-item">
                                <i class="fas fa-id-card"></i>
                                <span><?= htmlspecialchars($clearance['reg_number']) ?></span>
                            </div>
                            <div class="request-meta-item">
                                <i class="fas fa-calendar"></i>
                                <span><?= date('M j, Y', strtotime($clearance['updated_at'])) ?></span>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Reason</label>
                                <div class="form-control" style="background: #f9fafb;"><?= htmlspecialchars($clearance['reason']) ?></div>
                            </div>
                            
                            <div class="form-group">
                                <label>Staff Remarks</label>
                                <div class="form-control" style="background: #f9fafb;"><?= htmlspecialchars($clearance['remarks']) ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if(empty($completedClearances)): ?>
                    <div class="empty-state">
                        <i class="fas fa-check-circle"></i>
                        <h4>No Completed Requests</h4>
                        <p>There are no completed clearance requests to display.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Students (Keep as Table) -->
    <div id="students" class="content-section">
        <div class="table-container">
            <div class="table-title">
                <h3><i class="fas fa-user-graduate"></i> Student Records</h3>
            </div>
            
            <!-- Search Box -->
            <div class="search-container">
                <div class="search-box">
                    <input type="text" id="reg_number" class="search-input" placeholder="Enter registration number or student name to search...">
                    <i class="fas fa-search search-icon"></i>
                </div>
            </div>
            
            <table id="studentRecordsTable">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Reg No</th>
                        <th>Email</th>
                        <th>Faculty</th>
                        <th>Department</th>
                        <th>Program</th>
                    </tr>
                </thead>
                <tbody id="studentResults">
                    <?php foreach($students as $s): ?>
                        <tr class="student-row" data-reg="<?= htmlspecialchars(strtolower($s['reg_number'])) ?>" data-name="<?= htmlspecialchars(strtolower($s['full_name'])) ?>">
                            <td><?= htmlspecialchars($s['full_name']) ?></td>
                            <td><?= htmlspecialchars($s['reg_number']) ?></td>
                            <td><?= htmlspecialchars($s['email']) ?></td>
                            <td><?= htmlspecialchars($s['faculty_name']) ?></td>
                            <td><?= htmlspecialchars($s['dept_name']) ?></td>
                            <td><?= htmlspecialchars($s['program_name']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div id="noResults" class="no-results" style="display: none;">
                <i class="fas fa-search fa-2x mb-3" style="color: #d1d5db;"></i>
                <h4>No students found</h4>
                <p>No students match your search criteria.</p>
            </div>
        </div>
    </div>

    <!-- Coordinator Assignment -->
    <div id="coordinator-assignment" class="content-section">
        <div class="form-card">
            <div class="form-card-header">
                <i class="fas fa-tasks"></i>
                <h3>Coordinator Assignments</h3>
            </div>
            
            <div class="form-card-body">
                <?php foreach($assignments as $a): ?>
                    <?php 
                    $statusClass = 'status-pending';
                    if($a['status'] === 'Cleared') $statusClass = 'status-completed';
                    elseif($a['status'] === 'Rejected') $statusClass = 'status-rejected';
                    ?>
                    
                    <div class="assignment-card <?= $a['status'] === 'Cleared' ? 'completed' : ($a['status'] === 'Rejected' ? 'rejected' : '') ?>">
                        <div class="request-header">
                            <div class="request-title">
                                Assignment #<?= $a['assiment_id'] ?> - <?= htmlspecialchars($a['title']) ?>
                            </div>
                            <span class="status-badge <?= $statusClass ?>"><?= htmlspecialchars($a['status']) ?></span>
                        </div>
                        
                        <div class="request-meta">
                            <div class="request-meta-item">
                                <i class="fas fa-user-graduate"></i>
                                <span><?= htmlspecialchars($a['student_name']) ?> (<?= htmlspecialchars($a['reg_number']) ?>)</span>
                            </div>
                            <div class="request-meta-item">
                                <i class="fas fa-user-tie"></i>
                                <span><?= htmlspecialchars($a['staff_name']) ?></span>
                            </div>
                            <?php if($a['due_date']): ?>
                            <div class="request-meta-item">
                                <i class="fas fa-calendar-day"></i>
                                <span>Due: <?= date('M j, Y', strtotime($a['due_date'])) ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label>Assignment Description</label>
                            <div class="form-control form-textarea" style="background: #f9fafb; min-height: 60px;"><?= htmlspecialchars($a['description']) ?></div>
                        </div>
                        
                        <div class="request-meta">
                            <div class="request-meta-item">
                                <i class="fas fa-calendar"></i>
                                <span>Last Updated: <?= date('M j, Y', strtotime($a['updated_at'])) ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if(empty($assignments)): ?>
                    <div class="empty-state">
                        <i class="fas fa-tasks"></i>
                        <h4>No Coordinator Assignments</h4>
                        <p>There are no coordinator assignments assigned to you.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Financial Reports -->
    <div id="financial-reports" class="content-section">
        <div class="form-card">
            <div class="form-card-header">
                <i class="fas fa-chart-bar"></i>
                <h3>HOD Clearance Reports</h3>
            </div>
            
            <div class="form-card-body">
                <!-- Summary Stats -->
                <div class="form-row">
                    <div class="form-group">
                        <div class="stat-card" style="cursor: default; margin: 0;">
                            <div class="stat-icon completed"><i class="fas fa-check-circle"></i></div>
                            <div class="stat-value"><?= count(array_filter($completedClearances,fn($c)=>in_array($c['status'],['Cleared']))) ?></div>
                            <div class="stat-label">Total Approved</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="stat-card" style="cursor: default; margin: 0;">
                            <div class="stat-icon rejected"><i class="fas fa-times-circle"></i></div>
                            <div class="stat-value"><?= count(array_filter($completedClearances,fn($c)=>$c['status']==='Rejected')) ?></div>
                            <div class="stat-label">Total Rejected</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="stat-card" style="cursor: default; margin: 0;">
                            <div class="stat-icon total"><i class="fas fa-file-alt"></i></div>
                            <div class="stat-value"><?= count($completedClearances) ?></div>
                            <div class="stat-label">Total Processed</div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Activity -->
                <div class="form-group">
                    <label>Recent Clearance Activity</label>
                    <div class="form-card-body" style="padding: 0; gap: 10px;">
                        <?php 
                        $recentClearances = array_slice($completedClearances, 0, 5); // Show last 5
                        foreach($recentClearances as $c): 
                            $statusClass = 'status-pending';
                            if(in_array($c['status'], ['Cleared'])) $statusClass = 'status-approved';
                            elseif($c['status']==='Rejected') $statusClass = 'status-rejected';
                        ?>
                            <div class="request-item">
                                <div class="request-header">
                                    <div class="request-title" style="font-size: 14px;">
                                        <?= htmlspecialchars($c['student_name']) ?> (<?= htmlspecialchars($c['reg_number']) ?>)
                                    </div>
                                    <span class="status-badge <?= $statusClass ?>"><?= $c['status'] ?></span>
                                </div>
                                <div class="request-meta">
                                    <div class="request-meta-item">
                                        <i class="fas fa-calendar"></i>
                                        <span><?= date('M j, Y', strtotime($c['updated_at'])) ?></span>
                                    </div>
                                    <div class="request-meta-item">
                                        <i class="fas fa-comment"></i>
                                        <span><?= htmlspecialchars(substr($c['remarks'], 0, 50)) ?><?= strlen($c['remarks']) > 50 ? '...' : '' ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if(empty($recentClearances)): ?>
                            <div class="empty-state" style="padding: 20px;">
                                <i class="fas fa-chart-bar"></i>
                                <h4>No Report Data</h4>
                                <p>No clearance reports available for display.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JS -->
<script>
const menuItems = document.querySelectorAll('.menu-item');
const submenuItems = document.querySelectorAll('.submenu-item');
const contentSections = document.querySelectorAll('.content-section');

menuItems.forEach(menu => {
    menu.addEventListener('click', () => {
        const target = menu.dataset.target;
        if(target){
            contentSections.forEach(sec => sec.classList.remove('active'));
            document.getElementById(target).classList.add('active');

            menuItems.forEach(m=>m.classList.remove('active'));
            submenuItems.forEach(s=>s.classList.remove('active'));
            menu.classList.add('active');
        } else if(menu.classList.contains('has-submenu')){
            menu.classList.toggle('active');
        }
    });
});

submenuItems.forEach(sub => {
    sub.addEventListener('click', e => {
        e.stopPropagation();
        const target = sub.dataset.target;
        contentSections.forEach(section => section.classList.remove('active'));
        document.getElementById(target).classList.add('active');

        submenuItems.forEach(s => s.classList.remove('active'));
        sub.classList.add('active');

        menuItems.forEach(m => m.classList.remove('active'));
        const parentMenu = sub.closest('.submenu').previousElementSibling;
        parentMenu.classList.add('active');

        sub.closest('.submenu').style.display = 'flex';
    });
});

function showSection(id){
    contentSections.forEach(s=>s.classList.remove('active'));
    document.getElementById(id).classList.add('active');

    menuItems.forEach(m=>m.classList.remove('active'));
    submenuItems.forEach(s=>s.classList.remove('active'));

    const sub = document.querySelector(`.submenu-item[data-target="${id}"]`);
    if(sub){
        sub.classList.add('active');
        sub.closest('.submenu').previousElementSibling.classList.add('active');
        sub.closest('.submenu').style.display = 'flex';
    }
}

// Student Records Search Functionality (Client-side)
const regNumberInput = document.getElementById('reg_number');
const studentResults = document.getElementById('studentResults');
const noResults = document.getElementById('noResults');
const studentTable = document.getElementById('studentRecordsTable');
const studentRows = document.querySelectorAll('.student-row');

if (regNumberInput) {
    let searchTimeout;
    
    regNumberInput.addEventListener('input', function() {
        const searchTerm = this.value.trim().toLowerCase();
        
        clearTimeout(searchTimeout);
        
        searchTimeout = setTimeout(() => {
            performStudentSearch(searchTerm);
        }, 300);
    });
}

function performStudentSearch(searchTerm) {
    let found = false;
    
    studentRows.forEach(row => {
        const rowRegNumber = row.getAttribute('data-reg');
        const rowName = row.getAttribute('data-name');
        if (rowRegNumber.includes(searchTerm) || rowName.includes(searchTerm)) {
            row.style.display = '';
            found = true;
        } else {
            row.style.display = 'none';
        }
    });
    
    if (!found && searchTerm.length > 0) {
        studentTable.style.display = 'none';
        noResults.style.display = 'block';
    } else {
        studentTable.style.display = 'table';
        noResults.style.display = 'none';
    }
    
    // Show all if search is cleared
    if (searchTerm.length === 0) {
        studentRows.forEach(row => {
            row.style.display = '';
        });
        studentTable.style.display = 'table';
        noResults.style.display = 'none';
    }
}

// Pending Requests Search Functionality (Client-side)
const pendingSearchInput = document.getElementById('pendingSearch');
const pendingResults = document.getElementById('pendingResults');
const pendingRequests = document.querySelectorAll('.pending-request');

if (pendingSearchInput) {
    let pendingSearchTimeout;
    
    pendingSearchInput.addEventListener('input', function() {
        const searchTerm = this.value.trim().toLowerCase();
        
        clearTimeout(pendingSearchTimeout);
        
        pendingSearchTimeout = setTimeout(() => {
            performPendingSearch(searchTerm);
        }, 300);
    });
}

function performPendingSearch(searchTerm) {
    let found = false;
    
    pendingRequests.forEach(request => {
        const rowRegNumber = request.getAttribute('data-reg');
        const rowName = request.getAttribute('data-name');
        if (rowRegNumber.includes(searchTerm) || rowName.includes(searchTerm)) {
            request.style.display = 'block';
            found = true;
        } else {
            request.style.display = 'none';
        }
    });
    
    // Show empty state if no results
    const emptyState = document.querySelector('#pending-requests .empty-state');
    if (!found && searchTerm.length > 0) {
        if (emptyState) emptyState.style.display = 'none';
    } else if (!found && searchTerm.length === 0) {
        if (emptyState) emptyState.style.display = 'block';
    }
}

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = e.submitter;
            if (submitBtn && submitBtn.name === 'update_clearance') {
                const remarks = form.querySelector('input[name="remarks"]');
                if (!remarks || !remarks.value.trim()) {
                    e.preventDefault();
                    alert('Please enter remarks before submitting.');
                    remarks.focus();
                }
            }
        });
    });
});

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}
</script>

</body>
</html>