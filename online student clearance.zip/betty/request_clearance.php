<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php'; // PHPMailer

session_start();
require_once 'db_connect.php'; // PDO connection

// ✅ Ensure student is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// ✅ Fetch student details
$stmt = $pdo->prepare("
    SELECT s.student_id, s.reg_number, s.full_name, s.email,
           p.program_name, d.dept_name, f.faculty_name,
           s.dept_id, s.faculty_id
    FROM Student s
    JOIN Program p ON s.program_id = p.program_id
    JOIN Department d ON s.dept_id = d.dept_id
    JOIN Faculty f ON s.faculty_id = f.faculty_id
    WHERE s.student_id = ?
");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

// ✅ Define clearance categories
$categories = [
    'Payment'      => 'Finance',
    'Modules'      => 'HOD',
    'Library'      => 'Librarian',
    'Education'    => 'Dean',
    'Registration' => 'Register'
];

$categorySelected = $_POST['category'] ?? $_GET['category'] ?? null;
$categoryMessage = "";
$staffMembers = [];
$clearances = [];

// ✅ If category is selected, fetch staff + clearance info
if ($categorySelected && isset($categories[$categorySelected])) {
    $staffRole = $categories[$categorySelected];

    $staffStmt = $pdo->prepare("SELECT staff_id, full_name FROM Staff WHERE role = ?");
    $staffStmt->execute([$staffRole]);
    $staffMembers = $staffStmt->fetchAll(PDO::FETCH_ASSOC);

    $clearanceStmt = $pdo->prepare("
        SELECT c.status, c.remarks, s.full_name AS staff_name, c.reason
        FROM Clearance c
        JOIN Staff s ON c.staff_id = s.staff_id
        WHERE c.student_id = ? AND s.role = ?
    ");
    $clearanceStmt->execute([$student_id, $staffRole]);
    $clearances = $clearanceStmt->fetchAll(PDO::FETCH_ASSOC);

    $categoryMessage = "📌 Clearance info for <strong>$categorySelected</strong> category:";
}

// ✅ Handle clearance request submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_clearance'])) {
    $staff_id = $_POST['staff_id'];
    $category = $_POST['category'];
    $reason   = $_POST['reason'] ?? '';

    // 🔹 Check if a clearance request already exists for this student + staff
    $checkStmt = $pdo->prepare("SELECT * FROM Clearance WHERE student_id = ? AND staff_id = ? AND status IN ('Pending','Approved')");
    $checkStmt->execute([$student_id, $staff_id]);
    $existing = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        $_SESSION['clearance_message'] = "⚠️ You already have a clearance request with this staff member. Please wait until it is resolved.";
    } else {
        // ✅ Insert new request
        $insertStmt = $pdo->prepare("
            INSERT INTO Clearance (student_id, staff_id, status, remarks, reason, dept_id, faculty_id) 
            VALUES (?, ?, 'Pending', 'Waiting for review', ?, ?, ?)
        ");
        
        if ($insertStmt->execute([$student_id, $staff_id, $reason, $student['dept_id'], $student['faculty_id']])) {
            $_SESSION['clearance_message'] = "✅ Clearance request submitted successfully!";

            // ✅ Fetch staff email
            $staffStmt = $pdo->prepare("SELECT full_name, email FROM Staff WHERE staff_id = ?");
            $staffStmt->execute([$staff_id]);
            $staff = $staffStmt->fetch(PDO::FETCH_ASSOC);

            if ($staff) {
                $staffEmail   = $staff['email'];
                $staffName    = $staff['full_name'];
                $studentName  = $student['full_name'];
                $studentEmail = $student['email'];

                // --- Email to staff ---
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'sogoyahenry@gmail.com';
                    $mail->Password   = 'rxzh emte duin ikox'; // Gmail app password
                    $mail->SMTPSecure = 'tls';
                    $mail->Port       = 587;

                    $mail->setFrom('sogoyahenry@gmail.com', 'Clearance System');
                    $mail->addAddress($staffEmail, $staffName);
                    $mail->isHTML(true);
                    $mail->Subject = "New Clearance Request from $studentName";
                    $mail->Body    = "
                        Dear $staffName,<br><br>
                        A new clearance request has been submitted by <strong>$studentName</strong> 
                        (Reg No: {$student['reg_number']}, Program: {$student['program_name']}).<br><br>
                        <strong>Category:</strong> $category <br>
                        <strong>Reason:</strong> $reason <br><br>
                        <strong>Department:</strong> {$student['dept_name']} <br>
                        <strong>Faculty:</strong> {$student['faculty_name']} <br><br>
                        Please log in to the clearance system to review this request.<br><br>
                        Regards,<br>Clearance System
                    ";
                    $mail->send();
                } catch (Exception $e) {
                    error_log("Staff email could not be sent. Error: {$mail->ErrorInfo}");
                }

                // --- Confirmation email to student ---
                $mail2 = new PHPMailer(true);
                try {
                    $mail2->isSMTP();
                    $mail2->Host       = 'smtp.gmail.com';
                    $mail2->SMTPAuth   = true;
                    $mail2->Username   = 'sogoyahenry@gmail.com';
                    $mail2->Password   = 'rxzh emte duin ikox';
                    $mail2->SMTPSecure = 'tls';
                    $mail2->Port       = 587;

                    $mail2->setFrom('sogoyahenry@gmail.com', 'Clearance System');
                    $mail2->addAddress($studentEmail, $studentName);
                    $mail2->isHTML(true);
                    $mail2->Subject = "Your Clearance Request has been Submitted";
                    $mail2->Body    = "
                        Dear $studentName,<br><br>
                        Your clearance request for <strong>$category</strong> has been successfully submitted.<br>
                        <strong>Reason:</strong> $reason <br>
                        <strong>Department:</strong> {$student['dept_name']} <br>
                        <strong>Faculty:</strong> {$student['faculty_name']} <br><br>
                        You will be notified once the staff member has reviewed it.<br><br>
                        Regards,<br>Clearance System
                    ";
                    $mail2->send();
                } catch (Exception $e) {
                    error_log("Student email could not be sent. Error: {$mail2->ErrorInfo}");
                }
            }
        } else {
            $_SESSION['clearance_message'] = "❌ Error submitting clearance request.";
        }
    }

    header("Location: " . $_SERVER['PHP_SELF'] . "?category=" . urlencode($category));
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Clearance Portal</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --light: #f8f9fa;
            --dark: #212529;
            --gradient: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding-bottom: 2rem;
        }

        .header-card, .content-card, .progress-container {
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .header-card {
            background: var(--gradient);
            color: white;
        }

        .welcome-text { font-size: 2.2rem; font-weight: 700; margin-bottom: 0.5rem; }
        .student-info { background: rgba(255,255,255,0.2); border-radius: 10px; padding: 1.5rem; backdrop-filter: blur(10px); }
        .category-card { border: none; border-radius: 10px; overflow: hidden; margin-bottom: 1rem; }
        .category-header { background: var(--gradient); color: white; padding: 1rem; font-weight: 600; }
        .staff-item { border-left: 4px solid var(--primary); padding-left: 1rem; margin-bottom: 1.5rem; }
        .status-badge { padding: 0.5rem 1rem; border-radius: 50px; font-weight: 600; }
        .status-pending { background-color: #fff3cd; color: #856404; }
        .status-approved { background-color: #d1edff; color: #0c5460; }
        .status-completed { background-color: #d4edda; color: #155724; }
        .btn-request { background: var(--gradient); border: none; border-radius: 50px; padding: 0.5rem 1.5rem; font-weight: 600; }
        .category-select { border-radius: 10px; padding: 0.75rem; border: 2px solid #e9ecef; }
        .category-select:focus { border-color: var(--primary); box-shadow: none; }
        .reason-textarea { border-radius: 10px; padding: 1rem; border: 2px solid #e9ecef; resize: vertical; min-height: 120px; }
        .reason-textarea:focus { border-color: var(--primary); box-shadow: none; }
        .reason-display { background-color: #f8f9fa; border-radius: 10px; padding: 1rem; margin-top: 1rem; border-left: 4px solid var(--primary); }
        .alert-message { border-radius: 10px; border: none; }

        /* Gradient text for label */
.text-gradient {
    background: linear-gradient(90deg, #4b00e0, #8e2de2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* Custom placeholder color */
.reason-textarea::placeholder {
    color: #7a5af5;  /* purple shade */
    opacity: 0.8;    /* slightly lighter */
}
/* Gradient header */
.gradient-header {
    background: linear-gradient(90deg, #4b00e0, #8e2de2);
    font-size: 1.25rem;
    white-space: nowrap; /* keep h5 on one line */
}

/* Gradient label text */
.text-gradient {
    background: linear-gradient(90deg, #4b00e0, #8e2de2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* Placeholder */
.reason-textarea::placeholder {
    color: #7a5af5;
    opacity: 0.8;
}

/* Auto-expand textarea */
.reason-textarea {
    overflow: hidden;
    resize: none;
    min-height: 120px;
    font-size: 1rem;
}

/* Make modal bigger */
.modal-lg {
    max-width: 800px; /* wider modal */
}

    </style>
</head>
<body>
<div class="container mt-4">
    <!-- Header -->
    <div class="header-card">

        <h1 class="welcome-text">Hello, <?= htmlspecialchars($student['full_name']) ?>! 👋</h1>
        <p class="lead mb-0">Let's get you cleared for an amazing academic journey! 🚀</p>
        <div class="student-info mt-4">
            <div class="row text-white">
                <div class="col-md-3"><strong>Reg. Number:</strong> <?= htmlspecialchars($student['reg_number']) ?></div>
                <div class="col-md-3"><strong>Program:</strong> <?= htmlspecialchars($student['program_name']) ?></div>
                <div class="col-md-3"><strong>Department:</strong> <?= htmlspecialchars($student['dept_name']) ?></div>
                <div class="col-md-3"><strong>Faculty:</strong> <?= htmlspecialchars($student['faculty_name']) ?></div>
            </div>
        </div>
    </div>

    <!-- Messages -->
    <?php if (isset($_SESSION['clearance_message'])): ?>
        <div class="alert alert-dismissible fade show alert-message <?= strpos($_SESSION['clearance_message'], '✅') !== false ? 'alert-success' : 'alert-warning' ?>" role="alert">
            <?= $_SESSION['clearance_message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['clearance_message']); ?>
    <?php endif; ?>

    <!-- Clearance Progress -->
    <div class="progress-container">
        <h4>Your Clearance Progress</h4>
        <div class="progress mb-3" style="height: 20px;">
            <div class="progress-bar bg-success" role="progressbar" style="width: 25%;">25% Complete</div>
        </div>
    </div>

    <!-- Category Selection -->
    <div class="content-card">
        <form method="post">
            <div class="row">
                <div class="col-md-8">
                    <select class="form-select category-select" name="category" onchange="this.form.submit()">
                        <option value="">-- Choose a category --</option>
                        <?php foreach ($categories as $cat => $role): ?>
                            <option value="<?= $cat ?>" <?= $categorySelected === $cat ? 'selected' : '' ?>><?= $cat ?> Clearance (<?= $role ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </form>
    </div>

    <!-- Staff Clearance Info -->
    <?php if ($categorySelected): ?>
        <div class="content-card">
            <h4><?= $categoryMessage ?></h4>
            <?php if ($staffMembers): ?>
                <div class="row">
                    <?php foreach ($staffMembers as $staff): ?>
                        <?php
                            $c = array_filter($clearances, fn($cl) => $cl['staff_name'] === $staff['full_name']);
                            $c = array_values($c)[0] ?? null;
                            $status = $c ? $c['status'] : 'Pending';
                            $statusClass = $status === 'Approved' ? 'status-approved' : ($status === 'Completed' ? 'status-completed' : 'status-pending');
                        ?>
                        <div class="col-md-6 mb-4">
                            <div class="category-card">
                                <div class="category-header"><?= htmlspecialchars($staff['full_name']) ?></div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <span>Status:</span>
                                        <span class="status-badge <?= $statusClass ?>"><?= $status ?></span>
                                    </div>
                                    <div class="mb-3"><strong>Remarks:</strong><br><?= $c ? htmlspecialchars($c['remarks']) : 'Waiting for review 📝' ?></div>
                                    <?php if ($c && !empty($c['reason'])): ?>
                                        <div class="reason-display"><strong>Your Reason:</strong><br><?= htmlspecialchars($c['reason']) ?></div>
                                    <?php endif; ?>
                                    <?php if (!$c || $c['status'] === 'Pending'): ?>
                                        <button type="button" class="btn btn-request w-100 text-white mt-3" data-bs-toggle="modal" data-bs-target="#reasonModal<?= $staff['staff_id'] ?>">Request Clearance</button>
                                        <!-- Reason Modal -->
                                        <div class="modal fade" id="reasonModal<?= $staff['staff_id'] ?>" tabindex="-1">
                                          <div class="modal-dialog modal-lg"> <!-- make modal large -->
    <div class="modal-content">
        <div class="modal-header p-0">
            <h5 class="modal-title w-100 text-white text-center py-3 gradient-header text-nowrap">
                Request Clearance from <?= htmlspecialchars($staff['full_name']) ?>
            </h5>
            <button type="button" 
                    class="btn-close btn-close-white position-absolute end-0 me-3 mt-3" 
                    data-bs-dismiss="modal"></button>
        </div>

        <form method="post">
            <div class="modal-body">
                <p>Please provide a reason for your clearance request. This will be sent to the staff member.</p>
                <div class="mb-3">
                    <label for="reason<?= $staff['staff_id'] ?>" 
                           class="form-label fw-bold text-gradient">
                        Reason for Clearance:
                    </label>
                    <textarea class="form-control reason-textarea" 
                              id="reason<?= $staff['staff_id'] ?>" 
                              name="reason" 
                              placeholder="Explain why you need this clearance..." 
                              required></textarea>
                </div>
                <input type="hidden" name="staff_id" value="<?= $staff['staff_id'] ?>">
                <input type="hidden" name="category" value="<?= $categorySelected ?>">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="request_clearance" class="btn btn-request text-white">Submit Request</button>
            </div>
        </form>
    </div>
</div>

                                        </div>
                                    <?php else: ?>
                                        <div class="text-center text-success"><i class="fas fa-check-circle fa-2x mb-2"></i><p>Clearance request submitted!</p></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning text-center">No staff found for this category.</div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="text-center mt-4 text-muted"><p>Need help? Contact the administration office.</p></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-dismiss alerts
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => setTimeout(() => { new bootstrap.Alert(alert).close(); }, 5000));
});
// Auto-expand textarea
document.addEventListener("input", function(e) {
    if (e.target.classList.contains("reason-textarea")) {
        e.target.style.height = "auto";
        e.target.style.height = e.target.scrollHeight + "px";
    }
});

</script>
</body>
</html>