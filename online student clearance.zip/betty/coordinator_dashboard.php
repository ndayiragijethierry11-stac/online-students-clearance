
<?php
session_start();
require_once 'db_connect.php'; // PDO connection

// ✅ Ensure coordinator is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Coordinator') {
    header("Location: index.php");
    exit();
}

// Fetch all staff and students
$staffList = $pdo->query("
    SELECT sf.*, 
           d.dept_name, 
           f.faculty_name
    FROM Staff sf
    LEFT JOIN Department d ON sf.dept_id = d.dept_id
    LEFT JOIN Faculty f ON sf.faculty_id = f.faculty_id
    ORDER BY sf.full_name
")->fetchAll(PDO::FETCH_ASSOC);

$students  = $pdo->query("SELECT * FROM Student ORDER BY full_name")->fetchAll(PDO::FETCH_ASSOC);

// Handle staff deletion
if (isset($_POST['delete_staff'])) {
    $staff_id = $_POST['staff_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM Staff WHERE staff_id = ?");
        $stmt->execute([$staff_id]);
        $_SESSION['message'] = "✅ Staff deleted successfully.";
        $_SESSION['message_type'] = 'success';
    } catch (PDOException $e) {
        $_SESSION['message'] = "❌ Error deleting staff: " . $e->getMessage();
        $_SESSION['message_type'] = 'error';
    }
    header("Location: coordinator_dashboard.php#staff");
    exit();
}

// Handle adding new staff
if (isset($_POST['add_staff'])) {
    $full_name  = $_POST['full_name'];
    $email      = $_POST['email'];
    $role       = $_POST['role'];
    $password   = $_POST['password'];

    // Validate password length
    if (strlen($password) < 6) {
        $_SESSION['message'] = "❌ Password must be at least 6 characters long.";
        $_SESSION['message_type'] = 'error';
        header("Location: coordinator_dashboard.php#staff");
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT * FROM Staff WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() > 0) {
        $_SESSION['message'] = "❌ A staff member with this email already exists.";
        $_SESSION['message_type'] = 'error';
    } else {
        try {
            // Insert new staff member
            $stmt = $pdo->prepare("INSERT INTO Staff (full_name, email, role, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$full_name, $email, $role, $hashed_password]);
            $_SESSION['message'] = "✅ New staff member added successfully!";
            $_SESSION['message_type'] = 'success';
        } catch (PDOException $e) {
            $_SESSION['message'] = "❌ Error adding staff: " . $e->getMessage();
            $_SESSION['message_type'] = 'error';
        }
    }
    
    header("Location: coordinator_dashboard.php#staff");
    exit();
}

// Handle staff update with password
if (isset($_POST['update_staff'])) {
    $staff_id   = $_POST['staff_id'];
    $full_name  = $_POST['full_name'];
    $email      = $_POST['email'];
    $role       = $_POST['role'];
    $password   = $_POST['password']; // New password field

    try {
        // If password is provided, hash it and update
        if (!empty($password)) {
            if (strlen($password) < 6) {
                $_SESSION['message'] = "❌ Password must be at least 6 characters long.";
                $_SESSION['message_type'] = 'error';
                header("Location: coordinator_dashboard.php#staff");
                exit();
            }
            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE Staff SET full_name = ?, email = ?, role = ?, password = ? WHERE staff_id = ?");
            $stmt->execute([$full_name, $email, $role, $hashed_password, $staff_id]);
            $_SESSION['message'] = "✅ Staff updated successfully with new password.";
            $_SESSION['message_type'] = 'success';
        } else {
            // Update without changing password
            $stmt = $pdo->prepare("UPDATE Staff SET full_name = ?, email = ?, role = ? WHERE staff_id = ?");
            $stmt->execute([$full_name, $email, $role, $staff_id]);
            $_SESSION['message'] = "✅ Staff updated successfully.";
            $_SESSION['message_type'] = 'success';
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = "❌ Error updating staff: " . $e->getMessage();
        $_SESSION['message_type'] = 'error';
    }
    
    header("Location: coordinator_dashboard.php#staff");
    exit();
}

// Fetch staff grouped by role
$staffByRole = [];
foreach ($staffList as $staff) {
    $role = $staff['role'];
    if (!isset($staffByRole[$role])) {
        $staffByRole[$role] = [];
    }
    $staffByRole[$role][] = $staff;
}

// ✅ Fetch all assignments from the assiment table - UPDATED TO INCLUDE DEPARTMENT AND FACULTY INFO
$assignments = $pdo->query("
    SELECT a.assiment_id, a.title, a.description, a.status, a.created_at, a.dept_id, a.faculty_id,
           st.full_name AS student_name, sf.full_name AS staff_name,
           d.dept_name, f.faculty_name
    FROM assiment a
    JOIN Student st ON a.student_id = st.student_id
    JOIN Staff sf ON a.staff_id = sf.staff_id
    LEFT JOIN Department d ON a.dept_id = d.dept_id
    LEFT JOIN Faculty f ON a.faculty_id = f.faculty_id
    ORDER BY a.assiment_id DESC
")->fetchAll(PDO::FETCH_ASSOC);

// ✅ Fetch all clearance records as well
$clearances = $pdo->query("
    SELECT clearance_id, student_id, staff_id, status, remarks, reason, updated_at
    FROM Clearance
    ORDER BY clearance_id DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Handle auto-search for students
$searchedStudent = null;
if (isset($_POST['reg_number']) && !empty($_POST['reg_number'])) {
    $reg_number = $_POST['reg_number'];
    $stmt = $pdo->prepare("
        SELECT s.*, f.faculty_name, d.dept_name, p.program_name
        FROM Student s
        LEFT JOIN Faculty f ON s.faculty_id = f.faculty_id
        LEFT JOIN Department d ON s.dept_id = d.dept_id
        LEFT JOIN Program p ON s.program_id = p.program_id
        WHERE s.reg_number = ?
    ");
    $stmt->execute([$reg_number]);
    $searchedStudent = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Handle assignment creation
if (isset($_POST['assign_request'])) {
    $student_id = $_POST['student_id'];
    $staff_id = $_POST['staff_id'];
    $reason = $_POST['reason'];
    
    try {
        // Get student's faculty and department
        $stmt = $pdo->prepare("SELECT faculty_id, dept_id FROM Student WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $faculty_id = $student['faculty_id'];
        $dept_id = $student['dept_id'];
        
        // Insert assignment
        $stmt = $pdo->prepare("
            INSERT INTO assiment (student_id, staff_id, faculty_id, dept_id, title, description, status, created_at, updated_at) 
            VALUES (?, ?, ?, ?, 'Clearance Assignment', ?, 'Pending', NOW(), NOW())
        ");
        $stmt->execute([$student_id, $staff_id, $faculty_id, $dept_id, $reason]);
        
        $_SESSION['message'] = "✅ Assignment created successfully!";
        $_SESSION['message_type'] = 'success';
        
        // Reset searched student after successful assignment
        $searchedStudent = null;
        
    } catch (PDOException $e) {
        $_SESSION['message'] = "❌ Error creating assignment: " . $e->getMessage();
        $_SESSION['message_type'] = 'error';
    }
    
    header("Location: coordinator_dashboard.php#assign");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordinator Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a3f97;
            --secondary: #fcb612;
            --accent: #6c5ce7;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fb;
            color: #333;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, var(--primary) 0%, #3a2f87 100%);
            color: white;
            height: 100vh;
            position: fixed;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 1000;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-header {
            padding: 20px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-header h2 {
            font-size: 1.5rem;
            font-weight: 700;
            background: linear-gradient(to right, var(--secondary), #ffd166);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .sidebar-header i {
            font-size: 1.8rem;
            color: var(--secondary);
        }
        
        .sidebar-menu {
            padding: 15px 0;
        }
        
        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }
        
        .menu-item:hover {
            background-color: rgba(255, 255, 255, 0.1);
            border-left: 4px solid var(--secondary);
        }
        
        .menu-item.active {
            background-color: rgba(255, 255, 255, 0.15);
            border-left: 4px solid var(--secondary);
        }
        
        .menu-item i {
            font-size: 1.2rem;
            width: 24px;
            text-align: center;
        }
        
        .menu-text {
            font-weight: 500;
        }
        
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            background-color: rgba(0, 0, 0, 0.1);
        }
        
        .submenu.active {
            max-height: 200px;
        }
        
        .submenu-item {
            padding: 10px 20px 10px 50px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .submenu-item:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .submenu-item i {
            font-size: 0.9rem;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 20px;
            transition: all 0.3s ease;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            margin-bottom: 25px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .header h1 {
            color: var(--primary);
            font-size: 2rem;
            font-weight: 700;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary), var(--accent));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .welcome-message {
            background: linear-gradient(135deg, #e0f7fa, #bbdefb);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border-left: 5px solid var(--accent);
        }
        
        .welcome-message h2 {
            color: var(--primary);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .welcome-message p {
            color: #555;
            line-height: 1.6;
        }
        
        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-top: 4px solid var(--primary);
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--dark);
        }
        
        .card-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
        }
        
        .card-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            margin: 10px 0;
        }
        
        .card-footer {
            font-size: 0.9rem;
            color: #666;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        /* Table Styles */
        .table-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            overflow-x: auto;
        }
        
        .table-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .table-title h3 {
            color: var(--primary);
            font-size: 1.3rem;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        
        th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--dark);
        }
        
        tr:hover {
            background-color: #f8f9fa;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-submitted {
            background-color: #d1ecf1;
            color: #0c5460;
        }
        
        .status-reviewed {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }
        
        /* Form Styles */
        .form-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--dark);
        }
        
        input, select, textarea {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
            transition: border 0.3s ease;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(108, 92, 231, 0.2);
        }
        
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        /* Button Styles */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--accent));
            color: white;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #3a2f87, #5b4bc4);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.4);
        }
        
        .btn-success {
            background-color: var(--success);
            color: white;
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn-warning {
            background-color: var(--warning);
            color: var(--dark);
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.9rem;
        }
        
        /* Message Styles */
        .message {
            padding: 12px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .message-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid var(--success);
        }
        
        .message-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid var(--danger);
        }
        
        /* Search Section */
        .search-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .search-form {
            display: flex;
            gap: 10px;
            align-items: end;
        }
        
        .search-results {
            margin-top: 20px;
        }
        
        .student-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid var(--primary);
        }
        
        /* Staff Cards Styles */
        .staff-selection-section {
            margin: 20px 0;
        }
        
        .staff-cards-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .staff-card {
            display: flex;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .staff-card:hover {
            transform: translateY(-2px);
            border-color: var(--accent);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .staff-card.selected {
            border-color: var(--success);
            background: linear-gradient(135deg, #f8fff9, #e8f5e9);
            transform: scale(1.02);
        }
        
        .staff-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            margin-right: 15px;
        }
        
        .staff-info {
            flex: 1;
        }
        
        .staff-info h6 {
            margin: 0 0 5px 0;
            color: var(--dark);
            font-size: 1.1rem;
        }
        
        .staff-role {
            color: var(--primary);
            font-weight: 600;
            font-size: 0.9rem;
            margin: 0;
        }
        
        .staff-email {
            color: #666;
            font-size: 0.85rem;
            margin: 2px 0 0 0;
        }
        
        .staff-select-indicator {
            opacity: 0;
            color: var(--success);
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }
        
        .staff-card.selected .staff-select-indicator {
            opacity: 1;
            animation: bounceIn 0.5s ease;
        }
        
        /* Selected Staff Info */
        .selected-staff-info {
            background: linear-gradient(135deg, #e8f5e9, #f1f8e9);
            border: 2px solid var(--success);
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }
        
        .selected-staff-card {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .selected-staff-card .staff-avatar {
            width: 60px;
            height: 60px;
            font-size: 1.5rem;
        }
        
        .staff-details {
            flex: 1;
        }
        
        .staff-details strong {
            font-size: 1.2rem;
            color: var(--dark);
        }
        
        /* Toggle Button for Mobile */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1100;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 5px;
            width: 40px;
            height: 40px;
            font-size: 1.2rem;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }
        
        /* Password Field Styles */
        .password-field {
            position: relative;
            display: flex;
            align-items: center;
        }
        
        .password-input {
            padding-right: 40px !important;
        }
        
        .password-toggle {
            position: absolute;
            right: 10px;
            cursor: pointer;
            color: #666;
            transition: color 0.3s ease;
            z-index: 10;
        }
        
        .password-toggle:hover {
            color: var(--primary);
        }
        
        .form-input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.9rem;
            transition: border 0.3s ease;
        }
        
        .form-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(108, 92, 231, 0.2);
        }
        
        /* Password strength indicator */
        .password-strength {
            height: 4px;
            margin-top: 5px;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        
        .password-weak { background-color: #dc3545; width: 33%; }
        .password-medium { background-color: #ffc107; width: 66%; }
        .password-strong { background-color: #28a745; width: 100%; }
        
        /* Clearance Record Styles */
        .clearance-record {
            transition: all 0.3s ease;
        }
        
        .clearance-record:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .clearance-record.latest {
            animation: pulse-glow 2s infinite;
        }
        
        @keyframes pulse-glow {
            0% { box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
            50% { box-shadow: 0 2px 15px rgba(74, 63, 151, 0.2); }
            100% { box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        }
        
        .clearance-reason {
            position: relative;
        }
        
        .clearance-reason::before {
            content: '"';
            font-size: 2rem;
            color: var(--accent);
            opacity: 0.3;
            position: absolute;
            left: 5px;
            top: -5px;
            font-family: serif;
        }
        
        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
                overflow: visible;
            }
            
            .menu-text, .sidebar-header h2 {
                display: none;
            }
            
            .sidebar-header {
                justify-content: center;
                padding: 20px 10px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .menu-item {
                justify-content: center;
                padding: 15px 10px;
            }
            
            .submenu {
                position: absolute;
                left: 70px;
                top: 0;
                width: 200px;
                border-radius: 0 5px 5px 0;
                box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.1);
            }
            
            .submenu-item {
                padding: 10px 15px;
            }
            
            .search-form {
                flex-direction: column;
            }
            
            .staff-cards-container {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .sidebar-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            
            .clearance-record {
                padding: 10px !important;
                margin: 8px 0 !important;
            }
            
            .clearance-reason {
                font-size: 0.9rem !important;
                padding: 6px !important;
            }
            
            .status-badge {
                font-size: 0.75rem !important;
                padding: 3px 8px !important;
            }
        }
        
        /* Animation for enthusiasm */
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
            40% {transform: translateY(-10px);}
            60% {transform: translateY(-5px);}
        }
        
        .bounce {
            animation: bounce 2s infinite;
        }
        
        @keyframes pulse {
            0% {transform: scale(1);}
            50% {transform: scale(1.05);}
            100% {transform: scale(1);}
        }
        
        .pulse {
            animation: pulse 2s infinite;
        }
        
        .enthusiastic-element {
            transition: all 0.3s ease;
        }
        
        .enthusiastic-element:hover {
            transform: scale(1.05) rotate(2deg);
        }
        
        /* Section visibility */
        .content-section {
            display: none;
        }
        
        .content-section.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        
        /* Animations */
        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes bounceIn {
            0% { transform: scale(0.8); opacity: 0; }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); opacity: 1; }
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .assignment-success {
            animation: bounceIn 0.6s ease-out;
        }
        
        .filter-visible {
            animation: slideInUp 0.4s ease-out;
        }
        
        .loading-indicator {
            color: var(--primary);
            font-size: 0.9rem;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        /* User details section */
.user-details {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 20px 0;
    padding: 12px;
    border-radius: 10px;
    background: #2c3e50;
    color: #fff;
    transition: background 0.3s ease;
}

.user-details:hover {
    background: #34495e;
}

.user-avatar i {
    font-size: 40px;
    color: #1abc9c;
}

.user-info h4 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: #ecf0f1;
}

.user-info span {
    font-size: 13px;
    color: #bdc3c7;
}

/* Logout button */
.logout-form {
    margin: 10px 0;
    text-align: center;
}

.logout-btn {
    width: 100%;
    padding: 10px 15px;
    font-size: 14px;
    border: none;
    border-radius: 8px;
    background: #e74c3c;
    color: white;
    cursor: pointer;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: background 0.3s ease, transform 0.2s ease;
}

.logout-btn:hover {
    background: #c0392b;
    transform: scale(1.03);
}
/* User details section */
.user-details {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 20px 0;
    padding: 12px;
    border-radius: 10px;
    background: #2c3e50;
    color: #fff;
    transition: background 0.3s ease;
}

.user-details:hover {
    background: #34495e;
}

.user-avatar i {
    font-size: 40px;
    color: #1abc9c;
}

.user-info h4 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: #ecf0f1;
}

.user-info span {
    font-size: 13px;
    color: #bdc3c7;
}

/* Logout button */
.logout-form {
    margin: 10px 0;
    text-align: center;
}

.logout-btn {
    width: 100%;
    padding: 10px 15px;
    font-size: 14px;
    border: none;
    border-radius: 8px;
    background: #e74c3c;
    color: white;
    cursor: pointer;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: background 0.3s ease, transform 0.2s ease;
}

.logout-btn:hover {
    background: #c0392b;
    transform: scale(1.03);
}

    </style>
</head>
<body>
    <!-- Sidebar Toggle Button (Mobile) -->
    <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-user-shield bounce"></i>
            <h2>Coordinator Portal</h2>
        </div>
        
        <div class="sidebar-menu">
            <div class="menu-item active" data-target="dashboard">
                <i class="fas fa-tachometer-alt"></i>
                <span class="menu-text">Dashboard</span>
            </div>
            <div class="menu-item" data-target="assign">
                <i class="fas fa-tasks"></i>
                <span class="menu-text">Create Assignment</span>
            </div>
            
            <div class="menu-item has-submenu" data-target="assignments">
                <i class="fas fa-clipboard-list"></i>
                <span class="menu-text">Assignments</span>
                <i class="fas fa-chevron-down ml-auto"></i>
            </div>
            
            <div class="submenu">
                <div class="submenu-item" data-target="all-assignments">
                    <i class="fas fa-list"></i>
                    <span>All Assignments</span>
                </div>
                <div class="submenu-item" data-target="pending">
                    <i class="fas fa-clock"></i>
                    <span>Pending</span>
                </div>
                <div class="submenu-item" data-target="completed">
                    <i class="fas fa-check-circle"></i>
                    <span>Completed</span>
                </div>
            </div>
            
            <div class="menu-item" data-target="staff">
                <i class="fas fa-users"></i>
                <span class="menu-text">Staff Management</span>
            </div>
            
            
            <div class="menu-item" data-target="reports">
                <i class="fas fa-chart-bar"></i>
                <span class="menu-text">Reports & Analytics</span>
            </div>
            <div class="user-details">
    <div class="user-avatar">
        <i class="fas fa-user-circle"></i>
    </div>
    <div class="user-info">
        <h4><?php echo isset($_SESSION['full_name']) ? htmlspecialchars($_SESSION['full_name']) : 'Coordinator'; ?></h4>
        <span>Coordinator</span>
    </div>
</div>

<form method="POST" action="logout.php" class="logout-form">
    <button type="submit" class="logout-btn">
        <i class="fas fa-sign-out-alt"></i>
        Logout
    </button>
</form>

        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="header">
            <h1>Coordinator Dashboard</h1>
            <div class="user-info">
                <div class="user-avatar">
                    <?php 
                        $name = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'C';
                        echo strtoupper(substr($name, 0, 1)); 
                    ?>
                </div>
                <span><?php echo isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'Coordinator'; ?></span>
            </div>
        </div>
        
        <!-- Dashboard Section -->
        <div id="dashboard" class="content-section active">
            <div class="welcome-message enthusiastic-element">
                <h2><i class="fas fa-rocket pulse"></i> Welcome Back, Coordinator!</h2>
                <p>You're doing an amazing job managing the assignment process! Today you have <strong><?= count(array_filter($assignments, function($a) { return $a['status'] === 'Pending'; })) ?> pending assignments</strong> to review.</p>
            </div>
            
            <div class="dashboard-cards">
                <div class="card enthusiastic-element">
                    <div class="card-header">
                        <div class="card-title">Total Assignments</div>
                        <div class="card-icon" style="background: linear-gradient(135deg, #6c5ce7, #a29bfe);">
                            <i class="fas fa-clipboard-list"></i>
                        </div>
                    </div>
                    <div class="card-value"><?= count($assignments) ?></div>
                    <div class="card-footer">
                        <i class="fas fa-chart-line" style="color: var(--success);"></i>
                        <span>Assignment Management</span>
                    </div>
                </div>
                
                <div class="card enthusiastic-element">
                    <div class="card-header">
                        <div class="card-title">Pending</div>
                        <div class="card-icon" style="background: linear-gradient(135deg, #fd9644, #fed330);">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                    <div class="card-value"><?= count(array_filter($assignments, function($a) { return $a['status'] === 'Pending'; })) ?></div>
                    <div class="card-footer">
                        <i class="fas fa-exclamation-circle" style="color: var(--warning);"></i>
                        <span>Require attention</span>
                    </div>
                </div>
                
                <div class="card enthusiastic-element">
                    <div class="card-header">
                        <div class="card-title">Staff Members</div>
                        <div class="card-icon" style="background: linear-gradient(135deg, #2bcbba, #26de81);">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <div class="card-value"><?= count($staffList) ?></div>
                    <div class="card-footer">
                        <i class="fas fa-user-check" style="color: var(--info);"></i>
                        <span>Active staff</span>
                    </div>
                </div>
                
                <div class="card enthusiastic-element">
                    <div class="card-header">
                        <div class="card-title">Completion Rate</div>
                        <div class="card-icon" style="background: linear-gradient(135deg, #fc5c65, #fd9644);">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                    <div class="card-value">
                       <?php 
    // Count completed assignments
    $completed = count(array_filter($assignments, function($a) { 
    return $a['status'] === 'Cleared' || $a['status'] === 'Rejected';
}));

    

    // Count total assignments
    $total = count($assignments);

    // Calculate percentage
    $percentage = $total > 0 ? round(($completed / $total) * 100) : 0;

    echo $percentage . '%';
?>

                    </div>
                    <div class="card-footer">
                        <i class="fas fa-trophy" style="color: var(--secondary);"></i>
                        <span>Overall performance</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- All Assignments Section - UPDATED TO SHOW DEPARTMENT AND FACULTY -->
        <div id="all-assignments" class="content-section">
            <div class="table-container">
                <div class="table-title">
                    <h3><i class="fas fa-clipboard-list"></i> All Assignments</h3>
                    <button class="btn btn-primary btn-sm" onclick="refreshAssignments()">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                </div>
                
                <?php if (isset($_SESSION['message']) && $_SESSION['message_type'] === 'success'): ?>
                    <div class="message message-success">
                        <i class="fas fa-check-circle"></i>
                        <?= $_SESSION['message']; unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
                    </div>
                <?php endif; ?>
                
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Student</th>
                            <th>Staff</th>
                            <th>Department</th>
                            <th>Faculty</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($assignments as $a): ?>
                        <tr>
                            <td><?= $a['assiment_id'] ?></td>
                            <td><?= htmlspecialchars($a['title']) ?></td>
                            <td><?= htmlspecialchars($a['student_name']) ?></td>
                            <td><?= htmlspecialchars($a['staff_name']) ?></td>
                            <td><?= htmlspecialchars($a['dept_name'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($a['faculty_name'] ?? 'N/A') ?></td>
                            <td>
                                <span class="status-badge status-<?= strtolower($a['status']) ?>">
                                    <?= htmlspecialchars($a['status']) ?>
                                </span>
                            </td>
                            <td><?= date('M j, Y', strtotime($a['created_at'])) ?></td>
                            <td><?= htmlspecialchars(substr($a['description'], 0, 50)) ?>...</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Staff Management Section -->
        <div id="staff" class="content-section">
            <div class="table-container">
                <div class="table-title">
                    <h3><i class="fas fa-users"></i> Manage Staff</h3>
                    <button class="btn btn-primary btn-sm" onclick="togglePasswordVisibility()">
                        <i class="fas fa-eye"></i> Toggle Passwords
                    </button>
                </div>
                
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="message <?= $_SESSION['message_type'] === 'error' ? 'message-error' : 'message-success' ?>">
                        <i class="fas <?= $_SESSION['message_type'] === 'error' ? 'fa-exclamation-circle' : 'fa-check-circle' ?>"></i>
                        <?= $_SESSION['message']; unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
                    </div>
                <?php endif; ?>
                
                <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Password</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    <?php 
    $counter = 1; // start numbering at 1
    foreach ($staffList as $staff): 
    ?>
    <tr>
        <td><?= $counter ?></td> <!-- Auto numbering -->
        <td>
            <form method="POST" class="staff-form">
                <input type="hidden" name="staff_id" value="<?= $staff['staff_id'] ?>">
                <input type="text" name="full_name" value="<?= htmlspecialchars($staff['full_name']) ?>" 
                       class="form-input" required style="width: 100%;">
        </td>
        <td>
                <input type="email" name="email" value="<?= htmlspecialchars($staff['email']) ?>" 
                       class="form-input" required style="width: 100%;">
        </td>
        <td>
                <select name="role" class="form-input" required style="width: 100%;">
                    <option value="Advisor" <?= $staff['role'] == 'Advisor' ? 'selected' : '' ?>>Advisor</option>
                    <option value="Dean of CIS and  ES" <?= $staff['role'] == 'Dean of CIS and  ES' ? 'selected' : '' ?>>Dean of CIS and  ES</option>
                    <option value="Dean of ESM and Law" <?= $staff['role'] == 'Dean of ESM and Law' ? 'selected' : '' ?>>Dean of ESM and Law</option>
                    <option value="Library" <?= $staff['role'] == 'Library' ? 'selected' : '' ?>>Library</option>
                    <option value="register" <?= $staff['role'] == 'register' ? 'selected' : '' ?>>Registration</option>
                    <option value="Recovery" <?= $staff['role'] == 'Recovery' ? 'selected' : '' ?>>Recovery</option>
                    <option value="Finance" <?= $staff['role'] == 'Account officer' ? 'selected' : '' ?>>Account officer</option>
                    <option value="Coordinator" <?= $staff['role'] == 'Coordinator' ? 'selected' : '' ?>>Coordinator</option>
                </select>
        </td>
        <td>
                <div class="password-field">
                    <input type="password" name="password" placeholder="Leave blank to keep current" 
                           class="form-input password-input" autocomplete="new-password" style="width: 100%;">
                    <span class="password-toggle" onclick="togglePasswordField(this)">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
                <small style="font-size: 0.7rem; color: #666;">Min. 6 characters</small>
        </td>
        <td>
                <button type="submit" name="update_staff" class="btn btn-success btn-sm">
                    <i class="fas fa-save"></i> Update
                </button>
            </form>
            <form method="POST" style="display: inline;">
                <input type="hidden" name="staff_id" value="<?= $staff['staff_id'] ?>">
                <button type="submit" name="delete_staff" class="btn btn-danger btn-sm" 
                        onclick="return confirm('Are you sure you want to delete this staff member?')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </form>
        </td>
    </tr>
    <?php 
    $counter++; // increase row number
    endforeach; 
    ?>
</tbody>

            </table>
                
                <!-- Add New Staff Form -->
                <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                    <h4><i class="fas fa-user-plus"></i> Add New Staff Member</h4>
                    <form method="POST" id="addStaffForm">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px;">
                            <div class="form-group">
                                <label for="new_full_name">Full Name</label>
                                <input type="text" id="new_full_name" name="full_name" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label for="new_email">Email</label>
                                <input type="email" id="new_email" name="email" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label for="new_role">Role</label>
                                <select id="new_role" name="role" class="form-input" required>
                                    <option value="">Select Role</option>
                                    <option value="Advisor">Advisor</option>
                                    <option value="Dean of CIS and  ES">Dean of CIS and  ES</option>
                                    <option value="Dean of ESM and Law">Dean of ESM and Law</option>
                                    <option value="Library">Library</option>
                                    <option value="register">Registration</option>
                                    <option value="Account officer">Account officer</option>
                                    <option value="Recovery">Recovery</option>
                                    <option value="Coordinator">Coordinator</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="new_password">Password</label>
                                <div class="password-field">
                                    <input type="password" id="new_password" name="password" class="form-input" required minlength="6">
                                    <span class="password-toggle" onclick="togglePasswordField(this)">
                                        <i class="fas fa-eye"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <button type="submit" name="add_staff" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Staff Member
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Create Assignment Section -->
        <div id="assign" class="content-section">
            <div class="form-container">
                <div class="table-title">
                    <h3><i class="fas fa-tasks"></i> Create New Assignment</h3>
                </div>
                
                <!-- Student Auto-Search Form -->
                <div class="search-container" style="margin-bottom: 20px;">
                    <h4><i class="fas fa-search"></i> Search Student by Registration Number</h4>
                    <form method="POST" id="autoSearchForm" class="search-form">
                        <div class="form-group" style="flex: 1;">
                            <label for="reg_number">Registration Number</label>
                            <input type="text" id="reg_number" name="reg_number" 
                                   placeholder="Enter student registration number (auto-search)"
                                   value="<?= isset($_POST['reg_number']) ? htmlspecialchars($_POST['reg_number']) : '' ?>" 
                                   autocomplete="off">
                            <div id="searchLoading" class="loading-indicator" style="display: none;">
                                <i class="fas fa-spinner fa-spin"></i> Searching...
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Display Searched Student -->
                <div id="studentResults">
                    <?php if (isset($_POST['reg_number']) && $searchedStudent): ?>
                    <div class="student-info" style="margin-bottom: 20px;">
                        <h4><i class="fas fa-user-check"></i> Student Found - Review Details</h4>
                        <p><strong>Name:</strong> <?= htmlspecialchars($searchedStudent['full_name']) ?></p>
                        <p><strong>Registration Number:</strong> <?= htmlspecialchars($searchedStudent['reg_number']) ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($searchedStudent['email']) ?></p>
                        <p><strong>Faculty:</strong> <?= htmlspecialchars($searchedStudent['faculty_name']) ?></p>
                        <p><strong>Department:</strong> <?= htmlspecialchars($searchedStudent['dept_name']) ?></p>
                        <p><strong>Program:</strong> <?= htmlspecialchars($searchedStudent['program_name']) ?></p>

                        <!-- Display Reason for Clearance if exists -->
                        <?php
                        $stmtClearance = $pdo->prepare("SELECT reason, status FROM Clearance WHERE student_id = ? ORDER BY clearance_id DESC");
                        $stmtClearance->execute([$searchedStudent['student_id']]);
                        $clearanceRecords = $stmtClearance->fetchAll(PDO::FETCH_ASSOC);
                        if ($clearanceRecords):
                        ?>
                        <div class="clearance-history" style="margin: 20px 0; padding: 15px; background: linear-gradient(135deg, #f8f9fa, #e9ecef); border-radius: 10px; border-left: 4px solid var(--primary);">
                            <h5 style="color: var(--primary); margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                                <i class="fas fa-history"></i> Clearance Request History
                            </h5>
                            <div class="clearance-records">
                                <?php foreach ($clearanceRecords as $index => $record): ?>
                                <div class="clearance-record <?= $index === 0 ? 'latest' : '' ?>" style="
                                    background: white; 
                                    padding: 12px 15px; 
                                    margin: 10px 0; 
                                    border-radius: 8px; 
                                    border: 1px solid #e0e0e0;
                                    transition: all 0.3s ease;
                                    <?= $index === 0 ? 'border-left: 4px solid var(--success); box-shadow: 0 2px 8px rgba(0,0,0,0.1);' : '' ?>
                                ">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                        <span class="status-badge status-<?= strtolower($record['status']) ?>" style="
                                            padding: 4px 12px; 
                                            border-radius: 15px; 
                                            font-size: 0.8rem; 
                                            font-weight: 600;
                                            background-color: 
                                                <?= $record['status'] === 'Pending' ? '#fff3cd' : 
                                                   ($record['status'] === 'Approved' ? '#d4edda' : 
                                                   ($record['status'] === 'Rejected' ? '#f8d7da' : '#d1ecf1')) ?>;
                                            color: 
                                                <?= $record['status'] === 'Pending' ? '#856404' : 
                                                   ($record['status'] === 'Approved' ? '#155724' : 
                                                   ($record['status'] === 'Rejected' ? '#721c24' : '#0c5460')) ?>;
                                        ">
                                            <?= htmlspecialchars($record['status']) ?>
                                        </span>
                                        <?php if ($index === 0): ?>
                                        <span style="font-size: 0.8rem; color: var(--success); font-weight: 600;">
                                            <i class="fas fa-star"></i> Latest
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="clearance-reason" style="
                                        color: #555; 
                                        font-size: 0.95rem; 
                                        line-height: 1.4;
                                        padding: 8px;
                                        background: #f8f9fa;
                                        border-radius: 5px;
                                        border-left: 3px solid var(--accent);
                                    ">
                                        <strong style="color: var(--dark);">Reason:</strong> 
                                        <?= htmlspecialchars($record['reason']) ?>
                                    </div>
                                    <?php if ($index === 0 && $record['status'] === 'Pending'): ?>
                                    <div style="margin-top: 8px; font-size: 0.8rem; color: var(--warning);">
                                        <i class="fas fa-clock"></i> Awaiting approval
                                    </div>
                                    <?php elseif ($index === 0 && $record['status'] === 'Approved'): ?>
                                    <div style="margin-top: 8px; font-size: 0.8rem; color: var(--success);">
                                        <i class="fas fa-check-circle"></i> Cleared successfully
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="no-clearance" style="
                            margin: 20px 0; 
                            padding: 20px; 
                            background: linear-gradient(135deg, #fff3cd, #ffeaa7); 
                            border-radius: 10px; 
                            border-left: 4px solid var(--warning);
                            text-align: center;
                        ">
                            <i class="fas fa-info-circle" style="color: var(--warning); font-size: 1.5rem; margin-bottom: 10px;"></i>
                            <h5 style="color: #856404; margin-bottom: 5px;">No Clearance History</h5>
                            <p style="color: #856404; margin: 0; font-size: 0.9rem;">This student has no previous clearance requests.</p>
                        </div>
                        <?php endif; ?>

                        <!-- Assignment Form -->
                        <form method="POST" id="assignmentForm" style="margin-top: 15px;">
                            <input type="hidden" name="student_id" value="<?= $searchedStudent['student_id'] ?>">
                            <input type="hidden" name="reg_number" value="<?= htmlspecialchars($searchedStudent['reg_number']) ?>">
                            <input type="hidden" name="staff_id" id="selectedStaffId" value="">

                            <div class="form-group">
                                <label for="reason">Assignment Description:</label>
                                <textarea name="reason" required placeholder="Describe the assignment details..."></textarea>
                            </div>

                            <div class="form-group">
                                <label for="staff_role">Filter by Staff Role:</label>
                                <select id="staff_role" name="staff_role" onchange="filterStaffByRole()">
                                    <option value="">-- All Roles --</option>
                                    <?php foreach (array_keys($staffByRole) as $role): ?>
                                        <option value="<?= htmlspecialchars($role) ?>"><?= htmlspecialchars($role) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Staff Selection Cards -->
                            <div class="staff-selection-section">
                                <h5>Select Staff Member (Click to Assign):</h5>
                                <div class="staff-cards-container" id="staffCardsContainer">
                                    <?php foreach ($staffList as $staff): ?>
                                        <div class="staff-card" data-staff-id="<?= $staff['staff_id'] ?>" data-role="<?= htmlspecialchars($staff['role']) ?>">
                                            <div class="staff-avatar">
                                                <?= strtoupper(substr($staff['full_name'], 0, 1)) ?>
                                            </div>
                                            <div class="staff-info">
                                             <h6><?= htmlspecialchars($staff['full_name']) ?></h6>
                                        <p class="staff-role"><?= htmlspecialchars($staff['role']) ?></p>
                                <p class="staff-email"><?= htmlspecialchars($staff['email']) ?></p>
                                <p class="staff-dept"><strong>Department:</strong> <?= htmlspecialchars($staff['dept_name']) ?></p>
                                <p class="staff-faculty"><strong>Faculty:</strong> <?= htmlspecialchars($staff['faculty_name']) ?></p>
</div>

                                            <div class="staff-select-indicator">
                                                <i class="fas fa-check"></i>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div id="selectedStaffInfo" class="selected-staff-info" style="display: none;">
                                <h5><i class="fas fa-user-check"></i> Selected Staff:</h5>
                                <div id="selectedStaffDetails"></div>
                            </div>

                            <button type="submit" name="assign_request" class="btn btn-primary" id="assignButton" disabled>
                                <i class="fas fa-paper-plane"></i> Create Assignment
                            </button>
                        </form>
                    </div>
                    <?php elseif (isset($_POST['reg_number']) && !$searchedStudent): ?>
                    <div class="message message-error">
                        <i class="fas fa-exclamation-circle"></i>
                        No student found with registration number: "<?= htmlspecialchars($_POST['reg_number']) ?>"
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Pending Requests Section -->
        <div id="pending" class="content-section">
            <div class="table-container">
                <div class="table-title">
                    <h3><i class="fas fa-clock"></i> Pending Requests</h3>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Title / Reason</th>
                            <th>Student</th>
                            <th>Staff</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Combine assignments and clearances
                        $allPending = [];

                        // Pending assignments
                        foreach ($assignments as $a) {
                            if ($a['status'] === 'Pending') {
                                $allPending[] = [
                                    'id' => $a['assiment_id'],
                                    'type' => 'Assignment',
                                    'title' => $a['title'],
                                    'description' => $a['description'],
                                    'student_name' => $a['student_name'],
                                    'staff_name' => $a['staff_name'],
                                    'status' => $a['status'],
                                    'date' => $a['created_at']
                                ];
                            }
                        }

                        // Pending clearances
                        foreach ($clearances as $c) {
                            if ($c['status'] === 'Pending') {
                                // Fetch student and staff names
                                $studentName = '';
                                $staffName = '';
                                foreach ($students as $s) {
                                    if ($s['student_id'] == $c['student_id']) $studentName = $s['full_name'];
                                }
                                foreach ($staffList as $s) {
                                    if ($s['staff_id'] == $c['staff_id']) $staffName = $s['full_name'];
                                }
                                $allPending[] = [
                                    'id' => $c['clearance_id'],
                                    'type' => 'Clearance',
                                    'title' => $c['reason'],
                                    'description' => $c['remarks'],
                                    'student_name' => $studentName,
                                    'staff_name' => $staffName,
                                    'status' => $c['status'],
                                    'date' => $c['updated_at']
                                ];
                            }
                        }

                        // Display pending requests
                        if (!empty($allPending)) {
                            foreach ($allPending as $req): ?>
                            <tr>
                                <td><?= $req['id'] ?></td>
                                <td><?= $req['type'] ?></td>
                                <td><?= htmlspecialchars(substr($req['title'], 0, 50)) ?>...</td>
                                <td><?= htmlspecialchars($req['student_name']) ?></td>
                                <td><?= htmlspecialchars($req['staff_name']) ?></td>
                                <td>
                                    <span class="status-badge status-pending"><?= htmlspecialchars($req['status']) ?></span>
                                </td>
                                <td><?= date('M j, Y', strtotime($req['date'])) ?></td>
                            </tr>
                        <?php endforeach; 
                        } else { ?>
                            <tr>
                                <td colspan="7" style="text-align: center; color: #666;">No pending requests</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Completed Requests Section -->
        <div id="completed" class="content-section">
            <div class="table-container">
                <div class="table-title">
                    <h3><i class="fas fa-check-circle"></i> Completed Requests</h3>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Title / Reason</th>
                            <th>Student</th>
                            <th>Staff</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $allCompleted = [];

                        // Completed assignments
                        foreach ($assignments as $a) {
                            if ($a['status'] === 'Completed') {
                                $allCompleted[] = [
                                    'id' => $a['assiment_id'],
                                    'type' => 'Assignment',
                                    'title' => $a['title'],
                                    'description' => $a['description'],
                                    'student_name' => $a['student_name'],
                                    'staff_name' => $a['staff_name'],
                                    'status' => $a['status'],
                                    'date' => $a['created_at']
                                ];
                            }
                        }

                        // Completed clearances
                        foreach ($clearances as $c) {
                            if ($c['status'] === 'Completed') {
                                $studentName = '';
                                $staffName = '';
                                foreach ($students as $s) {
                                    if ($s['student_id'] == $c['student_id']) $studentName = $s['full_name'];
                                }
                                foreach ($staffList as $s) {
                                    if ($s['staff_id'] == $c['staff_id']) $staffName = $s['full_name'];
                                }
                                $allCompleted[] = [
                                    'id' => $c['clearance_id'],
                                    'type' => 'Clearance',
                                    'title' => $c['reason'],
                                    'description' => $c['remarks'],
                                    'student_name' => $studentName,
                                    'staff_name' => $staffName,
                                    'status' => $c['status'],
                                    'date' => $c['updated_at']
                                ];
                            }
                        }

                        if (!empty($allCompleted)) {
                            foreach ($allCompleted as $req): ?>
                            <tr>
                                <td><?= $req['id'] ?></td>
                                <td><?= $req['type'] ?></td>
                                <td><?= htmlspecialchars(substr($req['title'], 0, 50)) ?>...</td>
                                <td><?= htmlspecialchars($req['student_name']) ?></td>
                                <td><?= htmlspecialchars($req['staff_name']) ?></td>
                                <td>
                                    <span class="status-badge status-completed"><?= htmlspecialchars($req['status']) ?></span>
                                </td>
                                <td><?= date('M j, Y', strtotime($req['date'])) ?></td>
                            </tr>
                        <?php endforeach;
                        } else { ?>
                            <tr>
                                <td colspan="7" style="text-align: center; color: #666;">No completed requests</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Reports Section -->
        <div id="reports" class="content-section">
            <div class="table-container">
                <div class="table-title">
                    <h3><i class="fas fa-chart-bar"></i> Reports & Analytics</h3>
                </div>
                
                <div class="dashboard-cards">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Assignments by Status</div>
                            <div class="card-icon" style="background: linear-gradient(135deg, #6c5ce7, #a29bfe);">
                                <i class="fas fa-chart-pie"></i>
                            </div>
                        </div>
                        <div class="card-value">
                            <?php
                          $statusCounts = [
    'Pending'   => 0,
    'Submitted' => 0,
    'Reviewed'  => 0,
    'Completed' => 0
];

foreach ($assignments as $a) {
    $status = $a['status'] ?? 'Pending'; // default if null
    if (isset($statusCounts[$status])) {
        $statusCounts[$status]++;
    } else {
        // Handle unexpected statuses gracefully
        $statusCounts[$status] = 1;
    }
}
                            ?>
                            <div style="font-size: 0.9rem;">
                                <?php foreach ($statusCounts as $status => $count): ?>
                                <div style="display: flex; justify-content: space-between; margin: 5px 0;">
                                    <span><?= $status ?></span>
                                    <span style="font-weight: bold;"><?= $count ?></span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Recent Activity</div>
                            <div class="card-icon" style="background: linear-gradient(135deg, #fd9644, #fed330);">
                                <i class="fas fa-history"></i>
                            </div>
                        </div>
                        <div class="card-value">
                            <div style="font-size: 0.9rem;">
                                <?php 
                                $recentAssignments = array_slice($assignments, 0, 5);
                                foreach ($recentAssignments as $a): ?>
                                <div style="margin: 8px 0; padding-bottom: 8px; border-bottom: 1px solid #eee;">
                                    <strong><?= htmlspecialchars($a['student_name']) ?></strong><br>
                                    <small><?= $a['title'] ?> - <?= date('M j', strtotime($a['created_at'])) ?></small>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Staff data for JavaScript
        const staffByRole = <?php echo json_encode($staffByRole); ?>;

        // Handle URL hash to show correct section
        function handleHashNavigation() {
            const hash = window.location.hash.substring(1); // Remove the # symbol
            if (hash) {
                // Hide all content sections
                document.querySelectorAll('.content-section').forEach(section => {
                    section.classList.remove('active');
                });
                
                // Remove active class from all menu items
                document.querySelectorAll('.menu-item').forEach(item => {
                    item.classList.remove('active');
                });
                
                // Show the target section
                const targetSection = document.getElementById(hash);
                if (targetSection) {
                    targetSection.classList.add('active');
                    
                    // Activate the corresponding menu item
                    const menuItem = document.querySelector(`.menu-item[data-target="${hash}"]`);
                    if (menuItem) {
                        menuItem.classList.add('active');
                    }
                }
            }
        }

        // Sidebar functionality
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const menuItems = document.querySelectorAll('.menu-item');
            const contentSections = document.querySelectorAll('.content-section');
            
            // Handle hash navigation on page load
            handleHashNavigation();
            
            // Also handle hash changes
            window.addEventListener('hashchange', handleHashNavigation);
            
            // Toggle sidebar on mobile
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('active');
            });
            
            // Menu item functionality
            menuItems.forEach(item => {
                item.addEventListener('click', function() {
                    const target = this.getAttribute('data-target');
                    const hasSubmenu = this.classList.contains('has-submenu');
                    
                    if (hasSubmenu) {
                        const submenu = this.nextElementSibling;
                        submenu.classList.toggle('active');
                        
                        const icon = this.querySelector('.fa-chevron-down, .fa-chevron-up');
                        if (icon) {
                            icon.classList.toggle('fa-chevron-down');
                            icon.classList.toggle('fa-chevron-up');
                        }
                    } else {
                        // Update URL hash
                        window.location.hash = target;
                        
                        // Hide all content sections
                        contentSections.forEach(section => {
                            section.classList.remove('active');
                        });
                        
                        // Show the target section
                        const targetSection = document.getElementById(target);
                        if (targetSection) {
                            targetSection.classList.add('active');
                        }
                        
                        // Remove active class from all menu items
                        menuItems.forEach(i => i.classList.remove('active'));
                        // Add active class to clicked item
                        this.classList.add('active');
                    }
                });
            });
            
            // Submenu item functionality
            const submenuItems = document.querySelectorAll('.submenu-item');
            submenuItems.forEach(item => {
                item.addEventListener('click', function() {
                    const target = this.getAttribute('data-target');
                    
                    // Update URL hash
                    window.location.hash = target;
                    
                    // Hide all content sections
                    contentSections.forEach(section => {
                        section.classList.remove('active');
                    });
                    
                    // Show the target section
                    const targetSection = document.getElementById(target);
                    if (targetSection) {
                        targetSection.classList.add('active');
                    }
                    
                    // Update active menu item
                    menuItems.forEach(i => i.classList.remove('active'));
                    const parentMenuItem = this.closest('.submenu').previousElementSibling;
                    if (parentMenuItem) {
                        parentMenuItem.classList.add('active');
                    }
                });
            });
            
            // Auto-search functionality
            const regNumberInput = document.getElementById('reg_number');
            const searchLoading = document.getElementById('searchLoading');
            
            if (regNumberInput) {
                let searchTimeout;
                
                regNumberInput.addEventListener('input', function() {
                    const regNumber = this.value.trim();
                    
                    clearTimeout(searchTimeout);
                    
                    if (regNumber.length > 2) {
                        searchLoading.style.display = 'block';
                    }
                    
                    searchTimeout = setTimeout(() => {
                        if (regNumber.length > 2) {
                            performAutoSearch(regNumber);
                        } else if (regNumber.length === 0) {
                            document.getElementById('studentResults').innerHTML = '';
                            searchLoading.style.display = 'none';
                        }
                    }, 500);
                });
            }
            
            // Initialize staff cards
            initializeStaffCards();
            
            // Initialize password toggles
            initializePasswordToggles();
        });

        // Initialize password toggle functionality
        function initializePasswordToggles() {
            const passwordToggles = document.querySelectorAll('.password-toggle');
            
            passwordToggles.forEach(toggle => {
                toggle.addEventListener('click', function() {
                    togglePasswordField(this);
                });
            });
        }

        // Toggle password visibility for a single field
        function togglePasswordField(toggleElement) {
            const input = toggleElement.parentElement.querySelector('input');
            const icon = toggleElement.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        // Toggle all passwords visibility
        function togglePasswordVisibility() {
            const passwordInputs = document.querySelectorAll('.password-input');
            const toggleButton = document.querySelector('[onclick="togglePasswordVisibility()"]');
            const icon = toggleButton.querySelector('i');
            
            const allVisible = Array.from(passwordInputs).every(input => input.type === 'text');
            
            passwordInputs.forEach(input => {
                input.type = allVisible ? 'password' : 'text';
            });
            
            // Update all toggle icons
            const allToggles = document.querySelectorAll('.password-toggle i');
            allToggles.forEach(toggleIcon => {
                if (allVisible) {
                    toggleIcon.classList.remove('fa-eye-slash');
                    toggleIcon.classList.add('fa-eye');
                } else {
                    toggleIcon.classList.remove('fa-eye');
                    toggleIcon.classList.add('fa-eye-slash');
                }
            });
            
            if (allVisible) {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
                toggleButton.innerHTML = '<i class="fas fa-eye"></i> Show Passwords';
            } else {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
                toggleButton.innerHTML = '<i class="fas fa-eye-slash"></i> Hide Passwords';
            }
        }

        // Initialize staff card functionality
        function initializeStaffCards() {
            const staffCards = document.querySelectorAll('.staff-card');
            
            staffCards.forEach(card => {
                card.addEventListener('click', function() {
                    // Remove selected class from all cards
                    staffCards.forEach(c => c.classList.remove('selected'));
                    
                    // Add selected class to clicked card
                    this.classList.add('selected');
                    
                    // Get staff data
                    const staffId = this.getAttribute('data-staff-id');
                    const staffName = this.querySelector('h6').textContent;
                    const staffRole = this.querySelector('.staff-role').textContent;
                    const staffEmail = this.querySelector('.staff-email').textContent;
                    
                    // Update hidden input
                    document.getElementById('selectedStaffId').value = staffId;
                    
                    // Show selected staff info
                    const selectedStaffInfo = document.getElementById('selectedStaffInfo');
                    const selectedStaffDetails = document.getElementById('selectedStaffDetails');
                    const assignButton = document.getElementById('assignButton');
                    
                    selectedStaffDetails.innerHTML = `
                        <div class="selected-staff-card">
                            <div class="staff-avatar">${staffName.charAt(0)}</div>
                            <div class="staff-details">
                                <strong>${staffName}</strong><br>
                                <span class="staff-role">${staffRole}</span><br>
                                <span class="staff-email">${staffEmail}</span>
                            </div>
                        </div>
                    `;
                    
                    selectedStaffInfo.style.display = 'block';
                    assignButton.disabled = false;
                    
                    // Add animation
                    selectedStaffInfo.classList.add('assignment-success');
                    setTimeout(() => {
                        selectedStaffInfo.classList.remove('assignment-success');
                    }, 1000);
                });
            });
        }

        // Filter staff by role
        function filterStaffByRole() {
            const roleSelect = document.getElementById('staff_role');
            const staffCards = document.querySelectorAll('.staff-card');
            const selectedRole = roleSelect.value;
            
            staffCards.forEach(card => {
                if (selectedRole === '' || card.getAttribute('data-role') === selectedRole) {
                    card.style.display = 'flex';
                    card.classList.add('filter-visible');
                } else {
                    card.style.display = 'none';
                    card.classList.remove('filter-visible');
                }
            });
        }

        // Perform auto-search
        function performAutoSearch(regNumber) {
            const searchLoading = document.getElementById('searchLoading');
            const studentResults = document.getElementById('studentResults');
            
            const formData = new FormData();
            formData.append('reg_number', regNumber);
            formData.append('auto_search', 'true');
            
            fetch('coordinator_dashboard.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(html => {
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = html;
                const newResults = tempDiv.querySelector('#studentResults');
                
                if (newResults) {
                    studentResults.innerHTML = newResults.innerHTML;
                    setTimeout(initializeStaffCards, 100);
                }
                
                searchLoading.style.display = 'none';
            })
            .catch(error => {
                console.error('Search error:', error);
                searchLoading.style.display = 'none';
                studentResults.innerHTML = `
                    <div class="message message-error">
                        <i class="fas fa-exclamation-circle"></i>
                        Search failed. Please try again.
                    </div>
                `;
            });
        }

        // Refresh assignments
        function refreshAssignments() {
            location.reload();
        }

        // Password strength indicator
        function checkPasswordStrength(password) {
            let strength = 0;
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            return strength;
        }

        // Real-time password strength feedback
        document.addEventListener('DOMContentLoaded', function() {
            const passwordInputs = document.querySelectorAll('input[type="password"]');
            
            passwordInputs.forEach(input => {
                // Create strength indicator
                const strengthIndicator = document.createElement('div');
                strengthIndicator.className = 'password-strength';
                input.parentNode.appendChild(strengthIndicator);
                
                input.addEventListener('input', function() {
                    const password = this.value;
                    const strength = checkPasswordStrength(password);
                    
                    strengthIndicator.className = 'password-strength';
                    
                    if (password.length === 0) {
                        strengthIndicator.style.width = '0';
                    } else if (strength <= 2) {
                        strengthIndicator.classList.add('password-weak');
                    } else if (strength <= 4) {
                        strengthIndicator.classList.add('password-medium');
                    } else {
                        strengthIndicator.classList.add('password-strong');
                    }
                });
            });
            
            // Form validation for new staff
            const addStaffForm = document.getElementById('addStaffForm');
            if (addStaffForm) {
                addStaffForm.addEventListener('submit', function(e) {
                    const password = document.getElementById('new_password').value;
                    
                    if (password.length < 6) {
                        e.preventDefault();
                        alert('Password must be at least 6 characters long!');
                        document.getElementById('new_password').focus();
                    }
                });
            }
        });

        // Confetti effect
        function createConfetti() {
            const confettiCount = 30;
            const colors = ['#4a3f97', '#fcb612', '#6c5ce7', '#26de81', '#fd9644'];
            
            for (let i = 0; i < confettiCount; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.cssText = `
                    position: fixed;
                    width: 10px;
                    height: 10px;
                    background: ${colors[Math.floor(Math.random() * colors.length)]};
                    top: 0;
                    left: ${Math.random() * 100}vw;
                    border-radius: 2px;
                    z-index: 10000;
                    pointer-events: none;
                    animation: confetti-fall ${Math.random() * 3 + 2}s linear forwards;
                `;
                
                document.body.appendChild(confetti);
                
                setTimeout(() => {
                    confetti.remove();
                }, 5000);
            }
        }

        // Add confetti animation styles
        if (!document.querySelector('#confetti-styles')) {
            const style = document.createElement('style');
            style.id = 'confetti-styles';
            style.textContent = `
                @keyframes confetti-fall {
                    0% { transform: translateY(0) rotate(0deg); opacity: 1; }
                    100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }

        // Add confetti on form submission
        document.addEventListener('DOMContentLoaded', function() {
            const assignButton = document.getElementById('assignButton');
            if (assignButton) {
                assignButton.addEventListener('click', function() {
                    createConfetti();
                });
            }
        });

        // Add hover effects and animations to clearance records
        document.addEventListener('DOMContentLoaded', function() {
            const clearanceRecords = document.querySelectorAll('.clearance-record');
            
            clearanceRecords.forEach(record => {
                record.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateX(5px)';
                });
                
                record.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateX(0)';
                });
            });
            
            // Add animation to the latest record
            const latestRecord = document.querySelector('.clearance-record.latest');
            if (latestRecord) {
                setTimeout(() => {
                    latestRecord.style.animation = 'pulse-glow 2s infinite';
                }, 500);
            }
        });
    </script>
</body>
</html>