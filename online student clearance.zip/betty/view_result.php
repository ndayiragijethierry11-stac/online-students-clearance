<?php 
session_start();
require 'db_connect.php';

$student = null;
$clearances = [];

if(isset($_GET['id']) && isset($_GET['token'])) {
    $student_id = $_GET['id'];
    $token = $_GET['token'];
    
    // Verify token
    $stmt = $pdo->prepare("SELECT * FROM student WHERE student_id = ? AND access_token = ?");
    $stmt->execute([$student_id, $token]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($student) {
        // Fetch clearance info
        $stmt2 = $pdo->prepare("SELECT clearance_id, status, remarks, reason, appointment_date, updated_at 
                                FROM clearance 
                                WHERE student_id = ?");
        $stmt2->execute([$student_id]);
        $clearances = $stmt2->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Clearance Status</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: linear-gradient(135deg,#6a11cb,#2575fc);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #333;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding: 50px 20px;
}

.card {
    width: 100%;
    max-width: 700px;
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    padding: 30px;
    animation: fadeIn 1s ease;
}

h1 {
    font-size: 28px;
    text-align: center;
    margin-bottom: 20px;
    color: #2575fc;
}

.clearance-item {
    display: flex;
    justify-content: space-between;
    padding: 12px 15px;
    margin: 10px 0;
    border-radius: 10px;
    background: #f8f9fa;
    align-items: center;
    animation: slideUp 0.5s ease;
}

.status {
    font-weight: bold;
    padding: 5px 12px;
    border-radius: 20px;
    color: #fff;
    min-width: 100px;
    text-align: center;
    animation: pulse 2s infinite;
}

.status.pending { background: #ffc107; }
.status.cleared { background: #28a745; }
.status.rejected { background: #dc3545; }

.message-box {
    padding: 20px;
    border-radius: 12px;
    text-align: center;
    background: #e9f7ef;
    font-size: 18px;
    color: #155724;
    margin-top: 20px;
    animation: fadeIn 1.5s ease;
}

.footer-box {
    margin-top: 30px;
    padding: 15px;
    background: #f1f1f1;
    border-radius: 12px;
    text-align: center;
    font-weight: 500;
    color: #333;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px);}
    to { opacity: 1; transform: translateY(0);}
}

@keyframes slideUp {
    from { opacity: 0; transform: translateY(20px);}
    to { opacity: 1; transform: translateY(0);}
}
</style>
</head>
<body>
<div class="card">
<?php if(!$student): ?>
    <div class="message-box text-danger">Invalid or expired link!</div>
<?php else: ?>
    <h1>Clearance Status for <?= htmlspecialchars($student['full_name']) ?></h1>

    <?php if(empty($clearances)): ?>
        <div class="message-box">No clearance records found.</div>
    <?php else: ?>
        <?php 
        // check if any pending exists
        $hasPending = false;
        foreach($clearances as $c) {
            if(strtolower($c['status']) == 'pending') {
                $hasPending = true;
                break;
            }
        }
        ?>

        <?php if($hasPending): ?>
            <div class="message-box">
                🚀 Your clearance is being processed. Please be patient! <br>
                <small>We are updating your records as soon as possible.</small>
            </div>
        <?php endif; ?>

        <?php foreach($clearances as $c): ?>
            <div class="clearance-item">
                <div>
                    <strong><?= htmlspecialchars($c['reason']) ?></strong> <br>
                    <small>Remarks: <?= htmlspecialchars($c['remarks']) ?></small>
                </div>
                <div class="status <?= strtolower($c['status']) ?>">
                    <?= ucfirst($c['status']) ?>
                </div>
                <div>
                    <small>Appointment: <?= $c['appointment_date'] ? date('d M Y', strtotime($c['appointment_date'])) : 'None' ?></small>
                </div>
            </div>
        <?php endforeach; ?>

        <!-- Footer -->
        <div class="footer-box">
            Thank you  <strong> <?= htmlspecialchars($student['full_name']) ?> </strong>  for using this clearance system!
        </div>
    <?php endif; ?>
<?php endif; ?>
</div>
</body>
</html>
