<?php
session_start();
header('Content-Type: application/json');
require_once 'db_connect.php'; // <-- PDO connection file

$email = $_POST['email'] ?? '';
$password = $_POST['reg_number'] ?? '';
$otp = $_POST['otp'] ?? '';

if (empty($email) || empty($password) || empty($otp)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

if (!isset($_SESSION['otp'], $_SESSION['otp_expiry'], $_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'No OTP session found']);
    exit;
}

if (time() > $_SESSION['otp_expiry']) {
    unset($_SESSION['otp']);
    echo json_encode(['success' => false, 'message' => 'OTP expired']);
    exit;
}

if ($otp != $_SESSION['otp']) {
    echo json_encode(['success' => false, 'message' => 'Invalid OTP']);
    exit;
}

// ✅ OTP correct: login user
$user = $_SESSION['user'];
unset($_SESSION['otp'], $_SESSION['otp_expiry']); // remove OTP

if ($user['role'] === 'Student') {
    $_SESSION['student_id'] = $user['student_id'];
    $_SESSION['full_name'] = $user['full_name'];
    echo json_encode(['success' => true, 'role' => 'Student']);
} else {
    $_SESSION['staff_id'] = $user['staff_id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['full_name'] = $user['full_name'];
    echo json_encode(['success' => true, 'role' => $user['role']]);
}
?>
