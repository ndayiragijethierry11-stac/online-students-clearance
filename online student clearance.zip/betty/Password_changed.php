<?php 
session_start();
require 'db_connect.php';

$message = '';
$messageClass = '';

// Check if token and id are provided
if (!isset($_GET['token']) || !isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$token = $_GET['token'];
$student_id = $_GET['id'];

// Verify token
$stmt = $pdo->prepare("SELECT student_id FROM student WHERE student_id = ? AND access_token = ?");
$stmt->execute([$student_id, $token]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $_SESSION['flash_message'] = "❌ Invalid or expired reset link!";
    $_SESSION['flash_class'] = "error";
    header("Location: index.php");
    exit();
}

// Process password change
if (isset($_POST['change_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password !== $confirm_password) {
        $_SESSION['flash_message'] = "❌ Passwords do not match!";
        $_SESSION['flash_class'] = "error";
    } else {
        // 🚨 Save password in plain text (not hashed)
        $updateStmt = $pdo->prepare("UPDATE student SET reg_number = ?, access_token = NULL WHERE student_id = ?");
        $updateStmt->execute([$new_password, $student_id]);
        
        $_SESSION['flash_message'] = "🎉 Password changed successfully! You can now login with your new password.";
        $_SESSION['flash_class'] = "success";
        
        // Redirect to login page after successful password change
        header("Location: index.php");
        exit();
    }
}

// Show flash message
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    $messageClass = $_SESSION['flash_class'];
    unset($_SESSION['flash_message'], $_SESSION['flash_class']);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Password - University Clearance</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #4a3f97 0%, #6a5fbb 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .password-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            width: 100%;
            max-width: 900px;
            position: relative;
            transform: translateY(0);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .password-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 50px rgba(0,0,0,0.15);
        }

        .header-section {
            background: linear-gradient(135deg, #4a3f97, #6a5fbb);
            padding: 40px 30px;
            text-align: center;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: pulse 8s infinite linear;
        }

        @keyframes pulse {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .header-section h1 {
            font-size: 28px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            position: relative;
        }

        .header-section p {
            opacity: 0.9;
            font-size: 16px;
            position: relative;
        }

        .form-section {
            padding: 40px 30px;
            display: flex;
            gap: 30px;
            align-items: flex-start;
        }

        .form-column {
            flex: 1;
            min-width: 300px;
        }

        .criteria-column {
            flex: 1;
            min-width: 300px;
            position: sticky;
            top: 20px;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        .form-input:focus {
            outline: none;
            border-color: #4a3f97;
            background: white;
            box-shadow: 0 0 0 3px rgba(74, 63, 151, 0.1);
        }

        .form-input::placeholder {
            color: #a0a0a0;
        }

        .password-criteria {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 12px;
            border-left: 4px solid #4a3f97;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            height: fit-content;
        }

        .password-criteria h3 {
            color: #4a3f97;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            font-weight: 700;
        }

        .criteria-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 20px;
        }

        .criterion {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            color: #666;
            transition: all 0.3s ease;
            padding: 8px 0;
        }

        .criterion .icon {
            width: 22px;
            height: 22px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            background: #e9ecef;
            color: #6c757d;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        .criterion.valid .icon {
            background: #d4edda;
            color: #28a745;
        }

        .criterion.invalid .icon {
            background: #f8d7da;
            color: #dc3545;
        }

        .criterion.valid {
            color: #28a745;
        }

        .criterion.invalid {
            color: #dc3545;
        }

        .password-strength {
            padding: 15px;
            border-radius: 8px;
            background: #f8f9fa;
            text-align: center;
            font-weight: 600;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .strength-weak {
            background: #f8d7da;
            color: #721c24;
            border-color: #dc3545;
        }

        .strength-medium {
            background: #fff3cd;
            color: #856404;
            border-color: #ffc107;
        }

        .strength-strong {
            background: #d4edda;
            color: #155724;
            border-color: #28a745;
        }

        .change-button {
            width: 100%;
            background: linear-gradient(135deg, #fcb612, #e0a310);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            position: relative;
            overflow: hidden;
            margin-top: 10px;
        }

        .change-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: 0.5s;
        }

        .change-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(252, 182, 18, 0.4);
        }

        .change-button:hover::before {
            left: 100%;
        }

        .change-button:active {
            transform: translateY(0);
        }

        .change-button:disabled {
            background: #cccccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .change-button:disabled:hover::before {
            left: -100%;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #4a3f97;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: color 0.3s ease;
            padding: 8px 16px;
            border-radius: 5px;
        }

        .back-link a:hover {
            color: #6a5fbb;
            text-decoration: underline;
            background: rgba(74, 63, 151, 0.05);
        }

        .floating-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            z-index: -1;
        }

        .shape {
            position: absolute;
            background: rgba(252, 182, 18, 0.1);
            border-radius: 50%;
        }

        .shape-1 {
            width: 80px;
            height: 80px;
            top: -20px;
            right: -20px;
        }

        .shape-2 {
            width: 60px;
            height: 60px;
            bottom: 50px;
            left: -30px;
        }

        .shape-3 {
            width: 40px;
            height: 40px;
            bottom: -10px;
            right: 50px;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .floating {
            animation: float 3s ease-in-out infinite;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
            40% {transform: translateY(-5px);}
            60% {transform: translateY(-3px);}
        }

        .bounce {
            animation: bounce 1s;
        }

        @keyframes celebrate {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .celebrate {
            animation: celebrate 0.5s ease-in-out;
        }

        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .slide-in-right {
            animation: slideInRight 0.5s ease;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .form-section {
                flex-direction: column;
                gap: 20px;
            }
            
            .form-column, .criteria-column {
                min-width: 100%;
            }
            
            .criteria-column {
                position: static;
            }
            
            .password-container {
                max-width: 500px;
            }
        }

        @media (max-width: 480px) {
            .password-container {
                margin: 10px;
            }
            
            .header-section {
                padding: 30px 20px;
            }
            
            .form-section {
                padding: 30px 20px;
            }
            
            .password-criteria {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="floating-shapes">
        <div class="shape shape-1 floating" style="animation-delay: 0s;"></div>
        <div class="shape shape-2 floating" style="animation-delay: 1s;"></div>
        <div class="shape shape-3 floating" style="animation-delay: 2s;"></div>
    </div>

    <div class="password-container">
        <div class="header-section">
            <h1>🔑 Create New Password</h1>
            <p>Make it strong and memorable!</p>
        </div>

        <div class="form-section">
            <div class="form-column">
                <?php if (!empty($message)): ?>
                    <div class="<?php echo $messageClass === 'success' ? 'success-message' : 'error-message'; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" id="passwordForm">
                    <div class="form-group">
                        <label for="new_password">🔒 New Password</label>
                        <input 
                            type="password" 
                            id="new_password" 
                            name="new_password" 
                            class="form-input" 
                            placeholder="Create a strong password" 
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">🔁 Confirm Password</label>
                        <input 
                            type="password" 
                            id="confirm_password" 
                            name="confirm_password" 
                            class="form-input" 
                            placeholder="Re-enter your password" 
                            required
                        >
                    </div>

                    <button type="submit" name="change_password" class="change-button" id="submitButton" disabled>
                        🔄 Change Password
                    </button>
                </form>

                <div class="back-link">
                    <a href="index.php">← Back to Login</a>
                </div>
            </div>

            <!-- Password Criteria Section - Now on the right side -->
            <div class="criteria-column">
                <div class="password-criteria slide-in-right">
                    <h3>🔐 Password Requirements</h3>
                    <div class="criteria-list">
                        <div class="criterion" id="lengthCriterion">
                            <span class="icon">❌</span>
                            <span>At least 8 characters long</span>
                        </div>
                        <div class="criterion" id="uppercaseCriterion">
                            <span class="icon">❌</span>
                            <span>Contains uppercase letter</span>
                        </div>
                        <div class="criterion" id="lowercaseCriterion">
                            <span class="icon">❌</span>
                            <span>Contains lowercase letter</span>
                        </div>
                        <div class="criterion" id="numberCriterion">
                            <span class="icon">❌</span>
                            <span>Contains number</span>
                        </div>
                        <div class="criterion" id="specialCriterion">
                            <span class="icon">❌</span>
                            <span>Contains special character</span>
                        </div>
                        <div class="criterion" id="matchCriterion">
                            <span class="icon">❌</span>
                            <span>Passwords match</span>
                        </div>
                    </div>

                    <!-- Password Strength Meter -->
                    <div class="password-strength" id="passwordStrength">
                        ⚡ Password strength will appear here
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const newPasswordInput = document.getElementById('new_password');
            const confirmPasswordInput = document.getElementById('confirm_password');
            const submitButton = document.getElementById('submitButton');
            const passwordStrength = document.getElementById('passwordStrength');
            
            // Password criteria elements
            const lengthCriterion = document.getElementById('lengthCriterion');
            const uppercaseCriterion = document.getElementById('uppercaseCriterion');
            const lowercaseCriterion = document.getElementById('lowercaseCriterion');
            const numberCriterion = document.getElementById('numberCriterion');
            const specialCriterion = document.getElementById('specialCriterion');
            const matchCriterion = document.getElementById('matchCriterion');
            
            // Validate password as user types
            newPasswordInput.addEventListener('input', validatePassword);
            confirmPasswordInput.addEventListener('input', validatePassword);
            
            function validatePassword() {
                const password = newPasswordInput.value;
                const confirmPassword = confirmPasswordInput.value;
                
                // Check individual criteria
                const hasLength = password.length >= 8;
                const hasUppercase = /[A-Z]/.test(password);
                const hasLowercase = /[a-z]/.test(password);
                const hasNumber = /[0-9]/.test(password);
                const hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);
                const passwordsMatch = password === confirmPassword && password !== '';
                
                // Update criteria display
                updateCriterion(lengthCriterion, hasLength);
                updateCriterion(uppercaseCriterion, hasUppercase);
                updateCriterion(lowercaseCriterion, hasLowercase);
                updateCriterion(numberCriterion, hasNumber);
                updateCriterion(specialCriterion, hasSpecial);
                updateCriterion(matchCriterion, passwordsMatch);
                
                // Calculate password strength
                const strength = calculatePasswordStrength(
                    hasLength, hasUppercase, hasLowercase, hasNumber, hasSpecial
                );
                
                updatePasswordStrength(strength);
                
                // Enable submit button only if all requirements are met
                const allValid = hasLength && hasUppercase && hasLowercase && 
                               hasNumber && hasSpecial && passwordsMatch;
                submitButton.disabled = !allValid;
                
                return allValid;
            }
            
            function updateCriterion(element, isValid) {
                if (isValid) {
                    element.classList.remove('invalid');
                    element.classList.add('valid');
                    element.querySelector('.icon').textContent = '✅';
                    
                    // Add bounce animation when criterion becomes valid
                    element.querySelector('.icon').classList.add('bounce');
                    setTimeout(() => {
                        element.querySelector('.icon').classList.remove('bounce');
                    }, 1000);
                } else {
                    element.classList.remove('valid');
                    element.classList.add('invalid');
                    element.querySelector('.icon').textContent = '❌';
                }
            }
            
            function calculatePasswordStrength(hasLength, hasUppercase, hasLowercase, hasNumber, hasSpecial) {
                let strength = 0;
                let message = '';
                let className = '';
                
                if (hasLength) strength++;
                if (hasUppercase) strength++;
                if (hasLowercase) strength++;
                if (hasNumber) strength++;
                if (hasSpecial) strength++;
                
                switch(strength) {
                    case 0:
                    case 1:
                        message = '❌ Very Weak - Add more character types';
                        className = 'strength-weak';
                        break;
                    case 2:
                        message = '⚠️ Weak - Keep going!';
                        className = 'strength-weak';
                        break;
                    case 3:
                        message = '⚠️ Medium - Getting better!';
                        className = 'strength-medium';
                        break;
                    case 4:
                        message = '✅ Strong - Almost there!';
                        className = 'strength-strong';
                        break;
                    case 5:
                        message = '🎉 Excellent - Strong password!';
                        className = 'strength-strong';
                        break;
                }
                
                return { message, className };
            }
            
            function updatePasswordStrength(strength) {
                passwordStrength.textContent = strength.message;
                passwordStrength.className = 'password-strength ' + strength.className;
                
                // Add celebration animation for excellent strength
                if (strength.message.includes('Excellent')) {
                    passwordStrength.classList.add('celebrate');
                    setTimeout(() => {
                        passwordStrength.classList.remove('celebrate');
                    }, 500);
                }
            }
            
            // Add some interactive effects
            const inputs = document.querySelectorAll('.form-input');
            
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'scale(1.02)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'scale(1)';
                });
            });
        });
    </script>
</body>
</html>