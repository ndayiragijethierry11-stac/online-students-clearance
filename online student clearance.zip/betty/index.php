<?php
session_start();
require 'db_connect.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$message = '';
$messageClass = '';

if(isset($_POST['search'])) {
    $email = $_POST['searchdata'];

    // Fetch student
    $stmt = $pdo->prepare("SELECT student_id, full_name FROM student WHERE email=?");
    $stmt->execute([$email]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if($student){
        // Generate secure random token
        $token = bin2hex(random_bytes(32));
        
        // Store token in database
        $updateStmt = $pdo->prepare("UPDATE student SET access_token = ? WHERE student_id = ?");
        $updateStmt->execute([$token, $student['student_id']]);

        // Create link
        $link = "http://localhost/betty/view_result.php?id={$student['student_id']}&token=$token";

        // Send email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'sogoyahenry@gmail.com';
            $mail->Password = 'rxzh emte duin ikox'; // app password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('sogoyahenry@gmail.com', 'University Clearance');
            $mail->addAddress($email, $student['full_name']);
            $mail->isHTML(true);
            $mail->Subject = "View Your Clearance Result";
            $mail->Body = "Hello {$student['full_name']},<br>Click this link to view your clearance:<br><a href='$link'>$link</a>";$mail->Body = "
<div style='font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; background: #f5f5f5; padding: 20px;'>
    <div style='background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
        <div style='text-align: center; margin-bottom: 25px;'>
            <div style='background: #4a3f97; color: white; padding: 15px; border-radius: 5px; display: inline-block;'>
                <h2 style='margin: 0; font-size: 20px;'>Clearance Results</h2>
            </div>
        </div>
        
        <p style='color: #333; line-height: 1.6;'>Hello <strong>{$student['full_name']}</strong>,</p>
        
        <p style='color: #666; line-height: 1.6;'>
            Your clearance application has been processed. Click below to view your results:
        </p>
        
        <div style='text-align: center; margin: 30px 0;'>
            <a href='$link' style='
                background: #fcb612;
                color: white;
                padding: 14px 28px;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                display: inline-block;
                font-size: 16px;
            '>
                View My Results
            </a>
        </div>
        
        <hr style='border: none; border-top: 1px solid #eee; margin: 25px 0;'>
        
        <p style='color: #888; font-size: 13px; text-align: center;'>
            Can't click the button? Copy this link:<br>
            <span style='color: #4a3f97; background: #f9f9f9; padding: 8px; border-radius: 3px; font-size: 12px;'>$link</span>
        </p>
    </div>
</div>
";
            
            $mail->send();
            $_SESSION['flash_message'] = "✅ Link sent to your email!";
            $_SESSION['flash_class'] = "success";
        } catch (Exception $e) {
            $_SESSION['flash_message'] = "❌ Email could not be sent: ".$mail->ErrorInfo;
            $_SESSION['flash_class'] = "error";
        }
    } else {
        $_SESSION['flash_message'] = "❌ Email not found!";
        $_SESSION['flash_class'] = "error";
    }

    // Redirect to avoid resubmission on refresh
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Show flash message after redirect
if(isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    $messageClass = $_SESSION['flash_class'];
    unset($_SESSION['flash_message'], $_SESSION['flash_class']);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Portal</title>
    <style>
        /* Your existing CSS remains the same */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #4a3f97;
            color: white;
            overflow-x: hidden;
        }

        .background {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        .diamond {
            position: absolute;
            background-color: white;
            width: 30px;
            height: 30px;
            transform: rotate(45deg);
            opacity: 0.4;
            animation: moveUp linear infinite;
        }

        @keyframes moveUp {
            0% { bottom: -20px; }
            100% { bottom: 100%; }
        }

        .container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            min-height: 100vh;
            padding: 0 10%;
        }

        .form-left, .form-right {
            background-color: rgba(135, 206, 235, 0.5);
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            width: 40%;
            margin: 20px 0;
        }

        .apply-button, .check-button, .login-button, .otp-button, .paste-otp-button {
            background-color: #fcb612;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 18px;
            display: inline-block;
            margin: 10px 0;
            transition: background-color 0.3s;
        }

        .apply-button:hover, .check-button:hover, .login-button:hover, .otp-button:hover, .paste-otp-button:hover {
            background-color: #e0a310;
        }

        .input-text {
            display: block;
            width: 90%;
            margin: 20px auto;
            padding: 15px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            box-sizing: border-box;
        }

        footer {
            position: relative;
            width: 100%;
            text-align: center;
            padding: 10px 0;
            background-color: rgba(0, 0, 0, 0.2);
            margin-top: 20px;
        }

        a {
            color: #fcb612;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
        }

        a:hover {
            color: #ffffff;
            text-decoration: underline;
        }

        .message {
            color: #fcb612;
            font-size: 16px;
            margin: 10px 0;
        }
        
        table {
            width: 80%;
            margin: 30px auto;
            border-collapse: collapse;
            color: white;
            background-color: #4a3f97;
            position: relative;
        }

        table, th, td {
            border: 1px solid #fcb612;
        }

        th, td {
            padding: 12px;
            text-align: center;
            vertical-align: middle;
            color: white;
            font-size: 16px;
            font-family: Arial, sans-serif;
            word-wrap: break-word;
        }

        thead {
            background-color: #fcb612;
            color: #4a3f97;
        }

        tbody tr:nth-child(even) {
            background-color: rgba(255, 255, 255, 0.1);
        }

        tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .close-button {
            position: absolute;
            top: -15px;
            right: -15px;
            background-color: red;
            color: white;
            border: none;
            border-radius: 50%;
            padding: 8px 12px;
            font-size: 18px;
            cursor: pointer;
            z-index: 1;
        }

        .forgot-password, .back-home {
            display: block;
            margin-top: 10px;
            color: #fcb612;
            text-align: center;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .forgot-password:hover, .back-home:hover {
            color: #ffffff;
            text-decoration: underline;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.6);
        }

        .modal-content {
            background-color: #4a3f97;
            margin: 15% auto;
            padding: 20px;
            border: 2px solid #fcb612;
            border-radius: 10px;
            width: 60%;
            max-width: 500px;
            text-align: center;
            position: relative;
        }

        .close-modal {
            color: #fcb612;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            position: absolute;
            right: 15px;
            top: 5px;
        }

        .close-modal:hover {
            color: white;
        }

        .otp-section {
            display: none;
        }

        .student-table-container {
            width: 80%;
            margin: 30px auto;
            position: relative;
        }

        .table-title {
            text-align: center;
            margin-top: 30px;
            color: #fcb612;
        }
        
        .loading {
            display: none;
            text-align: center;
            margin: 10px 0;
        }
        
        .spinner {
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 4px solid #fcb612;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .otp-timer {
            color: #fcb612;
            font-size: 14px;
            margin: 10px 0;
        }
        
        .otp-input-container {
            position: relative;
            width: 90%;
            margin: 20px auto;
        }
        
        .paste-otp-button {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            padding: 8px 15px;
            font-size: 14px;
            background-color: #4a3f97;
            border: 1px solid #fcb612;
            cursor: pointer;
        }
        
        .paste-otp-button:hover {
            background-color: #5a4fa7;
        }
        
        .otp-input {
            display: block;
            width: 100% !important;
            margin: 0 !important;
            padding: 15px;
            padding-right: 120px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            box-sizing: border-box;
        }

        .demo-otp {
            background: rgba(252, 182, 18, 0.2);
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
            display: none;
        }
    .success {
            color: green;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid green;
            background: #f0fff0;
            transition: opacity 0.5s ease;
        }
        .error {
            color: red;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid red;
            background: #fff0f0;
            transition: opacity 0.5s ease;
        }
        
        .fade-out {
            opacity: 0;
        }
       .forgot-password-modern {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    color: white;
    text-decoration: none;
    font-weight: bold;
    font-size: 16px;
    padding: 12px 20px;
    border: 2px solid #fcb612;
    border-radius: 8px;
    margin: 15px 0;
    transition: all 0.3s ease;
    background: rgba(252, 182, 18, 0.1);
}

.forgot-password-modern:hover {
    background: #fcb612;
    color: #4a3f97;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(252, 182, 18, 0.3);
    text-decoration: none;
}

.forgot-password-modern .icon {
    font-size: 18px;
}
    </style>
</head>
<body>
    <div class="background">
        <!-- Diamonds will be added here dynamically -->
    </div>
    
    <div class="container">
        <div class="form-left">
            <h2>Check Application Status</h2>
            <p>Students who have already submitted their applications can verify the status of their application here or on your email.</p>
            
            <!-- Display message here -->
            <?php if (!empty($message)): ?>
                <div id="flash-message" class="<?php echo $messageClass; ?>"><?php echo $message; ?></div>
            <?php endif; ?>
            
            <form action="" method="POST" id="searchForm">
                <input id="searchdata" type="text" name="searchdata" required class="input-text" placeholder="Enter Your email...">
                <button type="submit" class="check-button" name="search">Search</button>
            </form>
        </div>
        
        <div class="form-right">
            <form id="loginForm" method="POST">
                <!-- Email Input -->
                <input id="user" type="text" name="email" placeholder="Email" class="input-text">
                <span id="user-message" class="message"></span>
                
                <!-- Registration Number Input -->
                <input id="pass" type="password" name="password" placeholder="Password" class="input-text">
                <span id="pass-message" class="message"></span>
                
                <div class="loading" id="otpLoading">
                    <div class="spinner"></div>
                    <p>Sending OTP...</p>
                </div>
                
                <button type="button" id="sendOtpButton" class="otp-button">Send OTP</button>
                
                <div class="otp-section" id="otpSection">
                    <div class="otp-input-container">
                        <input id="otp" type="text" name="otp" placeholder="Enter OTP" class="otp-input" maxlength="6">
                        <button type="button" id="pasteOtpButton" class="paste-otp-button">Paste OTP</button>
                    </div>
                    <span id="otp-message" class="message"></span>
                    <div id="otpTimer" class="otp-timer"></div>
                    
                    <div class="loading" id="loginLoading">
                        <div class="spinner"></div>
                        <p>Verifying OTP...</p>
                    </div>
                    
                    <button type="button" id="verifyLoginButton" class="login-button">Verify OTP & Login</button>
                </div>
 <a href="Password_reset.php" class="forgot-password-modern">
    <span class="icon">🔐</span>
    Change Your Password
</a>
            </form>
        </div>
    </div>

    <h2 class="table-title">Student Information</h2>
    <div class="student-table-container">
        <button class="close-button" onclick="closeTable()">×</button>
        <table id="studentTable">
            <thead>
                <tr>
                    <th>Registration Number</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Department ID</th>
                    <th>Faculty ID</th>
                    <th>Program ID</th>
                </tr>
            </thead>
            <tbody>
                <!-- Student data will be populated here -->
            </tbody>
        </table>
    </div>
    
    <footer>
        <p>© 2024 all rights reserved</p>
    </footer>

    <!-- Error Modal -->
    <div id="errorModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            <h3 id="modalTitle">Error</h3>
            <p id="modalMessage">An error occurred.</p>
            <button class="login-button" onclick="closeModal()">OK</button>
        </div>
    </div>

    <!-- Paste Instructions Modal -->
    <div id="pasteInstructionsModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closePasteInstructionsModal()">&times;</span>
            <h3>How to Paste OTP from Email</h3>
            <p>1. Open your email and find the OTP message</p>
            <p>2. Copy the 6-digit OTP code</p>
            <p>3. Click the "Paste OTP from Email" button below</p>
            <p>4. Allow clipboard access when prompted</p>
            <button type="button" class="paste-otp-button" onclick="pasteFromClipboard()">Paste OTP Now</button>
            <button class="login-button" onclick="closePasteInstructionsModal()">Cancel</button>
        </div>
    </div>

    <script>
let otpExpiryTime = null;
let otpTimerInterval = null;

document.addEventListener('DOMContentLoaded', function () {
    const fields = ['user', 'pass', 'otp'];

    fields.forEach(function (field) {
        const element = document.getElementById(field);
        if (element) {
            element.addEventListener('input', function () {
                document.getElementById(field + '-message').innerHTML = '';
            });
        }
    });

    // Generate diamonds dynamically
    for (let i = 0; i < 20; i++) {
        let diamond = document.createElement("div");
        diamond.className = "diamond";
        diamond.style.left = `${Math.random() * 100}%`;
        diamond.style.animationDuration = `${Math.random() * 5 + 5}s`;
        diamond.style.animationDelay = `${Math.random() * 3}s`;
        diamond.style.width = `${Math.random() * 50 + 10}px`;
        diamond.style.height = diamond.style.width;
        document.querySelector(".background").appendChild(diamond);
    }

    populateStudentTable();

    // Send OTP button
    document.getElementById('sendOtpButton').addEventListener('click', function() {
        if (validateEmail() && validateRegNumber()) sendOtpRequest();
    });

    // Paste OTP
    document.getElementById('pasteOtpButton').addEventListener('click', showPasteInstructions);

    // Verify Login
    document.getElementById('verifyLoginButton').addEventListener('click', startVerification);

    // Auto-format OTP
    document.getElementById('otp').addEventListener('input', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length === 6) {
            // Auto-verify when 6 digits are entered
            startVerification();
        }
    });
});

function validateEmail() {
    var email = document.getElementById("user").value;
    var emailMessage = document.getElementById("user-message");
    if (email.trim() === "") {
        emailMessage.innerHTML = "Please enter your email."; 
        return false;
    } else if (!isValidEmail(email)) {
        emailMessage.innerHTML = "Please enter a valid email address."; 
        return false;
    } else { 
        emailMessage.innerHTML = ""; 
        return true; 
    }
}

function validateRegNumber() {
    var regNumber = document.getElementById("pass").value;
    var regMessage = document.getElementById("pass-message");
    if (regNumber.trim() === "") { 
        regMessage.innerHTML = "Please enter your registration number."; 
        return false; 
    } else { 
        regMessage.innerHTML = ""; 
        return true; 
    }
}

function isValidEmail(email) { 
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); 
}

function validateLoginForm() {
    var email = document.getElementById("user").value;
    var regNumber = document.getElementById("pass").value;
    var otp = document.getElementById("otp").value;
    var emailMessage = document.getElementById("user-message");
    var regMessage = document.getElementById("pass-message");
    var otpMessage = document.getElementById("otp-message");
    var isValid = true;

    if (email.trim() === "") { 
        emailMessage.innerHTML = "Please enter your email."; 
        isValid = false; 
    } else if (!isValidEmail(email)) { 
        emailMessage.innerHTML = "Please enter a valid email address."; 
        isValid = false; 
    } else { 
        emailMessage.innerHTML = ""; 
    }

    if (regNumber.trim() === "") { 
        regMessage.innerHTML = "Please enter your password."; 
        isValid = false; 
    } else { 
        regMessage.innerHTML = ""; 
    }

    if (otp.trim() === "") { 
        otpMessage.innerHTML = "Please enter the OTP."; 
        isValid = false; 
    } else if (otp.length !== 6) { 
        otpMessage.innerHTML = "OTP must be 6 digits."; 
        isValid = false; 
    } else { 
        otpMessage.innerHTML = ""; 
    }

    return isValid;
}

function showPasteInstructions() { 
    document.getElementById('pasteInstructionsModal').style.display = 'block'; 
}

function closePasteInstructionsModal() { 
    document.getElementById('pasteInstructionsModal').style.display = 'none'; 
}

async function pasteFromClipboard() {
    try {
        const clipboardText = await navigator.clipboard.readText();
        const otpMatch = clipboardText.match(/\b\d{6}\b/);
        if (otpMatch) {
            document.getElementById('otp').value = otpMatch[0];
            closePasteInstructionsModal();
            showModal('Success', 'OTP pasted successfully! Verifying...');
            setTimeout(startVerification, 500);
        } else {
            showModal('No OTP Found', 'No 6-digit OTP found in clipboard. Please copy from your email.');
        }
    } catch (err) {
        console.error('Clipboard read failed:', err);
        const manualOtp = prompt('Please paste your OTP manually:');
        if (manualOtp && /^\d{6}$/.test(manualOtp)) {
            document.getElementById('otp').value = manualOtp;
            showModal('Success', 'OTP entered successfully! Verifying...');
            setTimeout(startVerification, 500);
        } else if (manualOtp) { 
            showModal('Invalid OTP', 'Enter a valid 6-digit OTP.'); 
        }
    }
}

function startVerification() {
    if (validateLoginForm()) {
        document.getElementById('loginLoading').style.display = 'block';
        document.getElementById('verifyLoginButton').disabled = true;
        verifyOtpAndLogin();
    }
}

 function sendOtpRequest() {
        const email = document.getElementById("user").value;
        const regNumber = document.getElementById("pass").value;
        document.getElementById('otpLoading').style.display = 'block';
        document.getElementById('sendOtpButton').disabled = true;

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "send_otp.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                document.getElementById('otpLoading').style.display = 'none';
                document.getElementById('sendOtpButton').disabled = false;
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (xhr.status === 200 && response.success) {
                        document.getElementById('otpSection').style.display = 'block';
                        otpExpiryTime = Date.now() + 10 * 60 * 1000;
                        startOtpTimer();
                        showModal('OTP Sent', response.message || 'Check your email for the OTP.');
                    } else {
                        showModal('Error', response.message || 'Failed to send OTP.');
                    }
                } catch { showModal('Error', 'Invalid response from server'); }
            }
        };
        xhr.onerror = () => {
            document.getElementById('otpLoading').style.display = 'none';
            document.getElementById('sendOtpButton').disabled = false;
            showModal('Error', 'Network error.');
        };
        xhr.send(`email=${encodeURIComponent(email)}&reg_number=${encodeURIComponent(regNumber)}`);
    }

 function verifyOtpAndLogin() {
        const email = document.getElementById("user").value;
        const regNumber = document.getElementById("pass").value;
        const otp = document.getElementById("otp").value;

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "verify_login.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                document.getElementById('loginLoading').style.display = 'none';
                document.getElementById('verifyLoginButton').disabled = false;
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        showModal('Login Successful', 'Redirecting...');
                        clearInterval(otpTimerInterval);
                        setTimeout(() => {
                            switch(response.role) {
                                case 'Student': window.location.href = 'applicationforclearance.php'; break;
                                case 'Coordinator': window.location.href = 'coordinator_dashboard.php'; break;
                                case 'Recovery': window.location.href = 'finance.php'; break;
                                case 'Librarian': window.location.href = 'librarian.php'; break;
                                case 'Dean of CIS and  ES':window.location.href = 'modulles.php'; break;
                                case 'Dean of ESM and Law': window.location.href = 'modules.php'; break;
                                case 'register': window.location.href = 'registration.php'; break;
                                case 'Account officer': window.location.href = 'Account.php'; break;
                                default: window.location.href = 'applicationforclearance.php';
                            }
                        }, 1500);
                    } else {
                        showModal('Login Failed', response.message || 'Invalid OTP or credentials.');
                    }
                } catch { showModal('Error', 'Invalid response from server'); }
            }
        };
        xhr.onerror = () => {
            document.getElementById('loginLoading').style.display = 'none';
            document.getElementById('verifyLoginButton').disabled = false;
            showModal('Error', 'Network error.');
        };
        xhr.send(`email=${encodeURIComponent(email)}&reg_number=${encodeURIComponent(regNumber)}&otp=${encodeURIComponent(otp)}`);
    }

function startOtpTimer() {
    clearInterval(otpTimerInterval);
    otpTimerInterval = setInterval(function() {
        const now = new Date().getTime();
        const distance = otpExpiryTime - now;
        if (distance <= 0) {
            clearInterval(otpTimerInterval);
            document.getElementById('otpTimer').innerHTML = "OTP expired. Request a new one.";
            document.getElementById('pasteOtpButton').disabled = true;
            document.getElementById('verifyLoginButton').disabled = true;
        } else {
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            document.getElementById('otpTimer').innerHTML = `OTP expires in: ${minutes}m ${seconds}s`;
        }
    }, 1000);
}

function closeTable() {
    const tableContainer = document.querySelector(".student-table-container");
    if (tableContainer) tableContainer.style.display = 'none';
}

function showModal(title, message) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalMessage').textContent = message;
    document.getElementById('errorModal').style.display = 'block';
}

function closeModal() { 
    document.getElementById('errorModal').style.display = 'none'; 
}

function populateStudentTable() {
    const students = [
        { reg_number: '2023001', full_name: 'John Doe', email: 'john.doe@university.edu', dept_id: 'D001', faculty_id: 'F001', program_id: 'P001' },
        { reg_number: '2023002', full_name: 'Jane Smith', email: 'jane.smith@university.edu', dept_id: 'D002', faculty_id: 'F001', program_id: 'P002' },
        { reg_number: '2023003', full_name: 'Michael Johnson', email: 'michael.j@university.edu', dept_id: 'D001', faculty_id: 'F002', program_id: 'P003' }
    ];

    const tbody = document.querySelector('#studentTable tbody');
    tbody.innerHTML = '';

    students.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.reg_number}</td>
            <td>${student.full_name}</td>
            <td>${student.email}</td>
            <td>${student.dept_id}</td>
            <td>${student.faculty_id}</td>
            <td>${student.program_id}</td>
        `;
        tbody.appendChild(row);
    });
}

window.onclick = function(event) {
    const modal = document.getElementById('errorModal');
    if (event.target == modal) closeModal();

    const pasteModal = document.getElementById('pasteInstructionsModal');
    if (event.target == pasteModal) closePasteInstructionsModal();
}
  document.addEventListener('DOMContentLoaded', function () {
        const flashMessage = document.getElementById('flash-message');
        if (flashMessage) {
            setTimeout(() => {
                flashMessage.classList.add('fade-out');
                setTimeout(() => {
                    flashMessage.remove();
                }, 500); // matches transition duration
            }, 4000); // show for 4s before fading
        }
    });
</script>

</body>
</html>