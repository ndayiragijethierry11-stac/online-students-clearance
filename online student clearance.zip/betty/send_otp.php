<?php
session_start();
header('Content-Type: application/json');

require_once 'db_connect.php'; // <-- PDO connection file
require 'vendor/autoload.php'; // PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$email = $_POST['email'] ?? '';
$password = $_POST['reg_number'] ?? ''; // for student: reg_number, for staff: password

if (empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required.']);
    exit;
}

try {
    // 🔎 Check if user is student
    $stmt = $pdo->prepare("SELECT student_id, reg_number, full_name, email, 'Student' AS role 
                           FROM student WHERE email = ? AND reg_number = ?");
    $stmt->execute([$email, $password]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    // 🔎 Check if user is staff
    $stmt = $pdo->prepare("SELECT staff_id, full_name, email, password, role 
                           FROM staff WHERE email = ?");
    $stmt->execute([$email]);
    $staff = $stmt->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if ($student) {
        $user = $student;
    } elseif ($staff && password_verify($password, $staff['password'])) {
        $user = $staff;
    }

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit;
    }

    // ✅ Generate OTP
    $otp = rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_expiry'] = time() + 600; // 10 min
    $_SESSION['user'] = $user;

    // ✅ Send email with PHPMailer
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Replace with your SMTP
        $mail->SMTPAuth   = true;
           $mail->Username   = 'sogoyahenry@gmail.com';
                    $mail->Password   = 'rxzh emte duin ikox'; // App password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('sogoyahenry@gmail.com', 'Clearance System');
        $mail->addAddress($user['email'], $user['full_name']);

        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body    = "<p>Dear {$user['full_name']},</p>
                          <p>Your OTP code is <b>$otp</b>. It will expire in 10 minutes.</p>
                          <p>Best regards,<br>Clearance Portal</p>";

        $mail->send();
        echo json_encode(['success' => true, 'message' => 'OTP sent to your email.', 'demo_otp' => $otp]); // demo_otp optional
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
