<?php
session_start();
require 'db_connect.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$message = '';
$messageClass = '';

if(isset($_POST['reset_password'])) {
    $email = $_POST['email'];

    // Fetch student
    $stmt = $pdo->prepare("SELECT student_id, full_name FROM student WHERE email=?");
    $stmt->execute([$email]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if($student){
        // Generate secure random token
        $token = bin2hex(random_bytes(32));
        
        // Store token in database
        $updateStmt = $pdo->prepare("UPDATE student SET access_token = ? WHERE student_id = ?");
        $updateStmt->execute([$token, $student['student_id']]);

        // Create link
        $link = "http://localhost/betty/Password_changed.php?id={$student['student_id']}&token=$token";

        // Send email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'sogoyahenry@gmail.com';
            $mail->Password = 'rxzh emte duin ikox'; // app password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('sogoyahenry@gmail.com', 'University Clearance');
            $mail->addAddress($email, $student['full_name']);
            $mail->isHTML(true);
            $mail->Subject = "Reset Your Password";
            $mail->Body = "
<div style='font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; background: #f5f5f5; padding: 20px;'>
    <div style='background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
        <div style='text-align: center; margin-bottom: 25px;'>
            <div style='background: linear-gradient(135deg, #4a3f97, #6a5fbb); color: white; padding: 15px; border-radius: 5px; display: inline-block;'>
                <h2 style='margin: 0; font-size: 20px;'>Reset Your Password</h2>
            </div>
        </div>
        
        <p style='color: #333; line-height: 1.6;'>Hello <strong>{$student['full_name']}</strong>,</p>
        
        <p style='color: #666; line-height: 1.6;'>
            We received a request to reset your password. Click the button below to create a new password:
        </p>
        
        <div style='text-align: center; margin: 30px 0;'>
            <a href='$link' style='
                background: linear-gradient(135deg, #fcb612, #e0a310);
                color: white;
                padding: 14px 28px;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                display: inline-block;
                font-size: 16px;
                box-shadow: 0 4px 15px rgba(252, 182, 18, 0.3);
            '>
                🔐 Reset Password
            </a>
        </div>
        
        <hr style='border: none; border-top: 1px solid #eee; margin: 25px 0;'>
        
        <p style='color: #888; font-size: 13px; text-align: center;'>
            Can't click the button? Copy this link:<br>
            <span style='color: #4a3f97; background: #f9f9f9; padding: 8px; border-radius: 3px; font-size: 12px; word-break: break-all;'>$link</span>
        </p>
        
        <p style='color: #999; font-size: 12px; text-align: center; margin-top: 20px;'>
            If you didn't request this reset, please ignore this email.
        </p>
    </div>
</div>
";
            
            $mail->send();
            $_SESSION['flash_message'] = "🎉 Password reset link sent to your email! Check your inbox!";
            $_SESSION['flash_class'] = "success";
        } catch (Exception $e) {
            $_SESSION['flash_message'] = "❌ Email could not be sent. Please try again later.";
            $_SESSION['flash_class'] = "error";
        }
    } else {
        $_SESSION['flash_message'] = "❌ Email not found! Please check and try again.";
        $_SESSION['flash_class'] = "error";
    }

    // Redirect to avoid resubmission on refresh
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Show flash message after redirect
if(isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    $messageClass = $_SESSION['flash_class'];
    unset($_SESSION['flash_message'], $_SESSION['flash_class']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Your Password - University Clearance</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #4a3f97 0%, #6a5fbb 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .reset-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            width: 100%;
            max-width: 450px;
            position: relative;
            transform: translateY(0);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .reset-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 50px rgba(0,0,0,0.15);
        }

        .header-section {
            background: linear-gradient(135deg, #4a3f97, #6a5fbb);
            padding: 40px 30px;
            text-align: center;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: pulse 8s infinite linear;
        }

        @keyframes pulse {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .header-section h1 {
            font-size: 28px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            position: relative;
        }

        .header-section p {
            opacity: 0.9;
            font-size: 16px;
            position: relative;
        }

        .form-section {
            padding: 40px 30px;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        .form-input:focus {
            outline: none;
            border-color: #4a3f97;
            background: white;
            box-shadow: 0 0 0 3px rgba(74, 63, 151, 0.1);
        }

        .form-input::placeholder {
            color: #a0a0a0;
        }

        .reset-button {
            width: 100%;
            background: linear-gradient(135deg, #fcb612, #e0a310);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            position: relative;
            overflow: hidden;
        }

        .reset-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: 0.5s;
        }

        .reset-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(252, 182, 18, 0.4);
        }

        .reset-button:hover::before {
            left: 100%;
        }

        .reset-button:active {
            transform: translateY(0);
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #4a3f97;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: color 0.3s ease;
            padding: 8px 16px;
            border-radius: 5px;
        }

        .back-link a:hover {
            color: #6a5fbb;
            text-decoration: underline;
            background: rgba(74, 63, 151, 0.05);
        }

        .steps-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 25px;
            border-left: 4px solid #fcb612;
        }

        .steps-info h3 {
            color: #4a3f97;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .steps-info ol {
            color: #666;
            padding-left: 20px;
        }

        .steps-info li {
            margin-bottom: 8px;
            line-height: 1.5;
            position: relative;
        }

        .steps-info li::marker {
            color: #fcb612;
            font-weight: bold;
        }

        .floating-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            z-index: -1;
        }

        .shape {
            position: absolute;
            background: rgba(252, 182, 18, 0.1);
            border-radius: 50%;
        }

        .shape-1 {
            width: 80px;
            height: 80px;
            top: -20px;
            right: -20px;
        }

        .shape-2 {
            width: 60px;
            height: 60px;
            bottom: 50px;
            left: -30px;
        }

        .shape-3 {
            width: 40px;
            height: 40px;
            bottom: -10px;
            right: 50px;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .floating {
            animation: float 3s ease-in-out infinite;
        }

        @media (max-width: 480px) {
            .reset-container {
                margin: 10px;
            }
            
            .header-section {
                padding: 30px 20px;
            }
            
            .form-section {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="floating-shapes">
        <div class="shape shape-1 floating" style="animation-delay: 0s;"></div>
        <div class="shape shape-2 floating" style="animation-delay: 1s;"></div>
        <div class="shape shape-3 floating" style="animation-delay: 2s;"></div>
    </div>

    <div class="reset-container">
        <div class="header-section">
            <h1>🔐 Reset Your Password</h1>
            <p>Let's get you back into your account securely!</p>
        </div>

        <div class="form-section">
            <?php if (!empty($message)): ?>
                <div class="<?php echo $messageClass === 'success' ? 'success-message' : 'error-message'; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="email">📧 Email Address</label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        class="form-input" 
                        placeholder="Enter your university email" 
                        required
                        value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                    >
                </div>

                <button type="submit" name="reset_password" class="reset-button">
                    📨 Send Reset Link
                </button>
            </form>

            <div class="steps-info">
                <h3>🛡️ Secure Password Reset Process:</h3>
                <ol>
                    <li>Enter your registered email address</li>
                    <li>Check your inbox for the secure reset link</li>
                    <li>Click the link to create a strong new password</li>
                    <li>Login with your new credentials</li>
                </ol>
            </div>

            <div class="back-link">
                <a href="index.php">← Back to Login</a>
            </div>
        </div>
    </div>

    <script>
        // Add some interactive effects
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = document.querySelectorAll('.form-input');
            
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'scale(1.02)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'scale(1)';
                });
            });

            // Auto-hide success messages after 5 seconds
            const successMessage = document.querySelector('.success-message');
            if (successMessage) {
                setTimeout(() => {
                    successMessage.style.opacity = '0';
                    setTimeout(() => {
                        successMessage.style.display = 'none';
                    }, 500);
                }, 5000);
            }
        });
    </script>
</body>
</html>